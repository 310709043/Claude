import AsyncStorage from "@react-native-async-storage/async-storage";

const KEYS = {
  USER: "life_echo_user",
  BIRTHDAY: "life_echo_birthday",
  CHECKINS: "life_echo_checkins",
  MOODS: "life_echo_moods",
  DIARIES: "life_echo_diaries",
  AVATAR: "life_echo_avatar",
  CHALLENGE_COMPLETED: "life_echo_challenge_completed",
  PERSONAL_TASKS: "life_echo_personal_tasks",
};

export interface UserData {
  username: string;
  createdAt: string;
}

export interface CheckIn {
  date: string;
  timestamp: number;
}

export type MoodType = "happy" | "normal" | "down" | "anxious" | "tired";

export interface MoodEntry {
  date: string;
  mood: MoodType;
  timestamp: number;
}

export interface DiaryEntry {
  date: string;
  text: string;
  timestamp: number;
}

export async function getUser(): Promise<UserData | null> {
  const data = await AsyncStorage.getItem(KEYS.USER);
  return data ? JSON.parse(data) : null;
}

export async function saveUser(user: UserData): Promise<void> {
  await AsyncStorage.setItem(KEYS.USER, JSON.stringify(user));
}

export async function clearUser(): Promise<void> {
  await AsyncStorage.multiRemove([KEYS.USER, KEYS.BIRTHDAY, KEYS.CHECKINS, KEYS.MOODS, KEYS.DIARIES]);
}

export async function isBirthdayLocked(): Promise<boolean> {
  const birthday = await getBirthday();
  return birthday !== null;
}

export async function getBirthday(): Promise<string | null> {
  return AsyncStorage.getItem(KEYS.BIRTHDAY);
}

export async function saveBirthday(date: string): Promise<void> {
  await AsyncStorage.setItem(KEYS.BIRTHDAY, date);
}

export async function getCheckIns(): Promise<CheckIn[]> {
  const data = await AsyncStorage.getItem(KEYS.CHECKINS);
  return data ? JSON.parse(data) : [];
}

export async function addCheckIn(): Promise<CheckIn> {
  const now = new Date();
  const dateStr = now.toISOString().split("T")[0];
  const checkins = await getCheckIns();
  const existing = checkins.find((c) => c.date === dateStr);
  if (existing) return existing;
  const entry: CheckIn = { date: dateStr, timestamp: now.getTime() };
  checkins.push(entry);
  await AsyncStorage.setItem(KEYS.CHECKINS, JSON.stringify(checkins));
  return entry;
}

export async function hasCheckedInToday(): Promise<boolean> {
  const checkins = await getCheckIns();
  const today = new Date().toISOString().split("T")[0];
  return checkins.some((c) => c.date === today);
}

export async function getStreak(): Promise<number> {
  const checkins = await getCheckIns();
  if (checkins.length === 0) return 0;
  const dates = checkins.map((c) => c.date).sort().reverse();
  const today = new Date().toISOString().split("T")[0];
  if (dates[0] !== today) return 0;
  let streak = 1;
  for (let i = 1; i < dates.length; i++) {
    const prev = new Date(dates[i - 1]);
    const curr = new Date(dates[i]);
    const diff = (prev.getTime() - curr.getTime()) / (1000 * 60 * 60 * 24);
    if (diff === 1) {
      streak++;
    } else {
      break;
    }
  }
  return streak;
}

export async function getMoods(): Promise<MoodEntry[]> {
  const data = await AsyncStorage.getItem(KEYS.MOODS);
  return data ? JSON.parse(data) : [];
}

export async function addMood(mood: MoodType): Promise<MoodEntry> {
  const now = new Date();
  const dateStr = now.toISOString().split("T")[0];
  const moods = await getMoods();
  const idx = moods.findIndex((m) => m.date === dateStr);
  const entry: MoodEntry = { date: dateStr, mood, timestamp: now.getTime() };
  if (idx >= 0) {
    moods[idx] = entry;
  } else {
    moods.push(entry);
  }
  await AsyncStorage.setItem(KEYS.MOODS, JSON.stringify(moods));
  return entry;
}

export async function getTodayMood(): Promise<MoodEntry | null> {
  const moods = await getMoods();
  const today = new Date().toISOString().split("T")[0];
  return moods.find((m) => m.date === today) || null;
}

export function getRecentMoods(moods: MoodEntry[], days: number = 7): MoodEntry[] {
  const now = new Date();
  const cutoff = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
  return moods
    .filter((m) => new Date(m.date) >= cutoff)
    .sort((a, b) => a.date.localeCompare(b.date));
}

export async function getDiaries(): Promise<DiaryEntry[]> {
  const data = await AsyncStorage.getItem(KEYS.DIARIES);
  return data ? JSON.parse(data) : [];
}

export async function saveDiary(text: string): Promise<DiaryEntry> {
  const now = new Date();
  const dateStr = now.toISOString().split("T")[0];
  const diaries = await getDiaries();
  const idx = diaries.findIndex((d) => d.date === dateStr);
  const entry: DiaryEntry = { date: dateStr, text, timestamp: now.getTime() };
  if (idx >= 0) {
    diaries[idx] = entry;
  } else {
    diaries.push(entry);
  }
  await AsyncStorage.setItem(KEYS.DIARIES, JSON.stringify(diaries));
  return entry;
}

export async function getTodayDiary(): Promise<DiaryEntry | null> {
  const diaries = await getDiaries();
  const today = new Date().toISOString().split("T")[0];
  return diaries.find((d) => d.date === today) || null;
}

export async function getAvatar(): Promise<string | null> {
  return AsyncStorage.getItem(KEYS.AVATAR);
}

export async function saveAvatar(uri: string): Promise<void> {
  await AsyncStorage.setItem(KEYS.AVATAR, uri);
}

export function getMoodForDate(moods: MoodEntry[], dateStr: string): MoodEntry | null {
  return moods.find((m) => m.date === dateStr) || null;
}

export interface CompletedChallenge {
  id: string;
  completedAt: string;
}

export interface PersonalTask {
  id: string;
  text: string;
  createdAt: string;
  completed: boolean;
}

export async function getCompletedChallenges(): Promise<CompletedChallenge[]> {
  const data = await AsyncStorage.getItem(KEYS.CHALLENGE_COMPLETED);
  return data ? JSON.parse(data) : [];
}

export async function toggleChallengeComplete(id: string): Promise<CompletedChallenge[]> {
  const completed = await getCompletedChallenges();
  const idx = completed.findIndex((c) => c.id === id);
  if (idx >= 0) {
    completed.splice(idx, 1);
  } else {
    completed.push({ id, completedAt: new Date().toISOString() });
  }
  await AsyncStorage.setItem(KEYS.CHALLENGE_COMPLETED, JSON.stringify(completed));
  return completed;
}

export async function getPersonalTasks(): Promise<PersonalTask[]> {
  const data = await AsyncStorage.getItem(KEYS.PERSONAL_TASKS);
  return data ? JSON.parse(data) : [];
}

export async function addPersonalTask(text: string): Promise<PersonalTask[]> {
  const tasks = await getPersonalTasks();
  const task: PersonalTask = {
    id: "pt_" + Date.now().toString() + Math.random().toString(36).substr(2, 9),
    text,
    createdAt: new Date().toISOString(),
    completed: false,
  };
  tasks.push(task);
  await AsyncStorage.setItem(KEYS.PERSONAL_TASKS, JSON.stringify(tasks));
  return tasks;
}

export async function togglePersonalTask(id: string): Promise<PersonalTask[]> {
  const tasks = await getPersonalTasks();
  const task = tasks.find((t) => t.id === id);
  if (task) {
    task.completed = !task.completed;
  }
  await AsyncStorage.setItem(KEYS.PERSONAL_TASKS, JSON.stringify(tasks));
  return tasks;
}

export async function deletePersonalTask(id: string): Promise<PersonalTask[]> {
  const tasks = await getPersonalTasks();
  const filtered = tasks.filter((t) => t.id !== id);
  await AsyncStorage.setItem(KEYS.PERSONAL_TASKS, JSON.stringify(filtered));
  return filtered;
}
