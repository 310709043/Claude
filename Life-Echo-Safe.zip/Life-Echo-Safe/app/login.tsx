import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  Platform,
  KeyboardAvoidingView,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useThemeColors } from "@/lib/ThemeContext";
import { useApp } from "@/lib/AppContext";
import { useI18n } from "@/lib/i18n";
import FloatingLeaves from "@/components/FloatingLeaves";

export default function LoginScreen() {
  const insets = useSafeAreaInsets();
  const colors = useThemeColors();
  const { login } = useApp();
  const { t, lang } = useI18n();
  const [name, setName] = useState("");
  const [isFocused, setIsFocused] = useState(false);

  const handleLogin = async () => {
    if (!name.trim()) return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await login(name.trim());
    router.replace("/(tabs)");
  };

  const webTopInset = Platform.OS === "web" ? 67 : 0;

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientMid, colors.gradientEnd]}
      style={styles.gradient}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
    >
      <FloatingLeaves />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <View
          style={[
            styles.container,
            {
              paddingTop: insets.top + webTopInset + 60,
              paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 20),
            },
          ]}
        >
          <View style={styles.topSection}>
            <View style={[styles.iconCircle, { backgroundColor: "rgba(232, 145, 110, 0.10)" }]}>
              <View style={styles.logoCombo}>
                <MaterialCommunityIcons name="notebook-outline" size={32} color={colors.coral} style={styles.notebookIcon} />
                <Ionicons name="leaf" size={20} color="#A8C5A0" style={styles.leafIcon} />
              </View>
            </View>
            <Text style={[styles.title, { color: colors.textPrimary }]}>
              {lang === "zh" ? "\u9918\u751F\u8A18" : "Life Echo"}
            </Text>
            <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
              {lang === "zh" ? "Life Echo" : "\u9918\u751F\u8A18"}
            </Text>
            <Text style={[styles.description, { color: colors.textMuted }]}>
              {t("appTagline")}
            </Text>
          </View>

          <View style={styles.formSection}>
            <Text style={[styles.label, { color: colors.textSecondary }]}>{t("yourName")}</Text>
            <View
              style={[
                styles.inputWrapper,
                { backgroundColor: colors.cardBg, borderColor: colors.border },
                isFocused && { borderColor: colors.coralSoft },
              ]}
            >
              <Ionicons
                name="person-outline"
                size={20}
                color={isFocused ? colors.coral : colors.textMuted}
                style={styles.inputIcon}
              />
              <TextInput
                style={[styles.input, { color: colors.textPrimary }]}
                placeholder={t("enterName")}
                placeholderTextColor={colors.textMuted}
                value={name}
                onChangeText={setName}
                onFocus={() => setIsFocused(true)}
                onBlur={() => setIsFocused(false)}
                returnKeyType="done"
                onSubmitEditing={handleLogin}
              />
            </View>

            <Pressable
              onPress={handleLogin}
              disabled={!name.trim()}
              style={({ pressed }) => [
                styles.button,
                { backgroundColor: name.trim() ? colors.coral : colors.border },
                pressed && name.trim() && { transform: [{ scale: 0.97 }], opacity: 0.9 },
              ]}
            >
              <Text style={[styles.buttonText, { color: name.trim() ? "#FFF" : colors.textMuted }]}>
                {t("startJourney")}
              </Text>
              <Ionicons
                name="arrow-forward"
                size={18}
                color={name.trim() ? "#FFF" : colors.textMuted}
              />
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  gradient: { flex: 1 },
  container: {
    flex: 1,
    paddingHorizontal: 32,
    justifyContent: "space-between",
    zIndex: 1,
  },
  topSection: {
    alignItems: "center",
    gap: 8,
    marginTop: 40,
  },
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
  },
  logoCombo: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  notebookIcon: {
    marginRight: -4,
  },
  leafIcon: {
    marginLeft: -4,
    marginTop: -10,
    transform: [{ rotate: "-30deg" }],
  },
  title: {
    fontSize: 36,
    fontFamily: "NotoSansTC_700Bold",
    letterSpacing: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: "NotoSansTC_400Regular",
    letterSpacing: 6,
    textTransform: "uppercase",
  },
  description: {
    fontSize: 14,
    fontFamily: "NotoSansTC_400Regular",
    marginTop: 8,
  },
  formSection: {
    gap: 16,
    marginBottom: 40,
  },
  label: {
    fontSize: 14,
    fontFamily: "NotoSansTC_500Medium",
    marginLeft: 4,
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 16,
    borderWidth: 1.5,
    paddingHorizontal: 16,
    height: 56,
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    fontFamily: "NotoSansTC_400Regular",
  },
  button: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 16,
    height: 56,
    gap: 8,
    shadowColor: "#E8916E",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  buttonText: {
    fontSize: 17,
    fontFamily: "NotoSansTC_700Bold",
  },
});
