const EXPECTED_AGE = 80;

export interface LifeStats {
  ageYears: number;
  ageMonths: number;
  ageDays: number;
  remainingYears: number;
  remainingMonths: number;
  remainingWeeks: number;
  remainingDays: number;
  remainingWeekends: number;
  remainingHours: number;
  remainingMinutes: number;
  remainingSeconds: number;
  totalWeeksLived: number;
  totalWeeksRemaining: number;
  totalWeeksLife: number;
  progressPercent: number;
  daysLived: number;
  totalDaysLife: number;
}

export function calculateLifeStats(birthdayStr: string): LifeStats {
  const birthday = new Date(birthdayStr);
  const now = new Date();

  const totalDaysLife = EXPECTED_AGE * 365.25;
  const diffMs = now.getTime() - birthday.getTime();
  const daysLived = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  const ageYears = Math.floor(daysLived / 365.25);
  const ageMonths = Math.floor((daysLived % 365.25) / 30.44);
  const ageDays = Math.floor((daysLived % 365.25) % 30.44);

  const remainingDaysTotal = Math.max(0, Math.floor(totalDaysLife - daysLived));
  const remainingYears = Math.floor(remainingDaysTotal / 365.25);
  const remainingMonths = Math.floor((remainingDaysTotal % 365.25) / 30.44);
  const remainingWeeks = Math.floor(remainingDaysTotal / 7);
  const remainingDays = remainingDaysTotal;
  const remainingWeekends = Math.floor(remainingDaysTotal / 7);

  const totalWeeksLived = Math.floor(daysLived / 7);
  const totalWeeksRemaining = Math.floor(remainingDaysTotal / 7);
  const totalWeeksLife = Math.floor(totalDaysLife / 7);

  const progressPercent = Math.min(100, Math.max(0, (daysLived / totalDaysLife) * 100));

  const endDate = new Date(birthday.getTime() + EXPECTED_AGE * 365.25 * 24 * 60 * 60 * 1000);
  const remainingMs = Math.max(0, endDate.getTime() - now.getTime());
  const remainingTotalSeconds = Math.floor(remainingMs / 1000);
  const remainingHours = Math.floor((remainingTotalSeconds % (24 * 3600)) / 3600);
  const remainingMinutes = Math.floor((remainingTotalSeconds % 3600) / 60);
  const remainingSeconds = remainingTotalSeconds % 60;

  return {
    ageYears,
    ageMonths,
    ageDays,
    remainingYears,
    remainingMonths,
    remainingWeeks,
    remainingDays,
    remainingWeekends,
    remainingHours,
    remainingMinutes,
    remainingSeconds,
    totalWeeksLived,
    totalWeeksRemaining,
    totalWeeksLife,
    progressPercent,
    daysLived,
    totalDaysLife: Math.floor(totalDaysLife),
  };
}
