import React, { useEffect, useState, useRef, useCallback } from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  Platform,
  ScrollView,
  Share,
  Modal,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSpring,
  withDelay,
  withSequence,
  Easing,
} from "react-native-reanimated";
import Svg, { Circle } from "react-native-svg";
import { LinearGradient } from "expo-linear-gradient";
import { useThemeColors } from "@/lib/ThemeContext";
import { useApp } from "@/lib/AppContext";
import { useI18n } from "@/lib/i18n";
import { calculateLifeStats } from "@/lib/life-calculator";
import { getDailyQuote } from "@/lib/quotes";
import MarqueeBanner from "@/components/MarqueeBanner";
import FloatingTexts from "@/components/FloatingTexts";

const AnimatedCircle = Animated.createAnimatedComponent(Circle);

function ProgressRing({ progress, size = 180, strokeWidth = 10, colors }: { progress: number; size?: number; strokeWidth?: number; colors: any }) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const animValue = useSharedValue(0);

  useEffect(() => {
    animValue.value = withDelay(300, withTiming(progress / 100, { duration: 1500, easing: Easing.out(Easing.cubic) }));
  }, [progress]);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      strokeDashoffset: circumference * (1 - animValue.value),
    };
  });

  return (
    <Svg width={size} height={size} style={{ transform: [{ rotate: "-90deg" }] }}>
      <Circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        stroke={colors.peachLight}
        strokeWidth={strokeWidth}
        fill="none"
        opacity={0.4}
      />
      <AnimatedCircle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        stroke={colors.coral}
        strokeWidth={strokeWidth}
        fill="none"
        strokeDasharray={`${circumference} ${circumference}`}
        strokeLinecap="round"
        animatedProps={animatedStyle}
      />
    </Svg>
  );
}

function TickingDigit({ value, colors }: { value: string; colors: any }) {
  const pulse = useSharedValue(1);

  useEffect(() => {
    pulse.value = withSequence(
      withTiming(0.85, { duration: 80 }),
      withSpring(1, { damping: 12, stiffness: 200 })
    );
  }, [value]);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulse.value }],
    opacity: 0.3 + pulse.value * 0.7,
  }));

  return (
    <Animated.Text style={[styles.timeValue, { color: colors.coral }, animStyle]}>
      {value}
    </Animated.Text>
  );
}

function LiveCountdownTimer({ birthday, colors }: { birthday: string; colors: any }) {
  const { t } = useI18n();
  const [timeLeft, setTimeLeft] = useState({ days: "0", hours: "00", minutes: "00", seconds: "00" });
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const compute = useCallback(() => {
    const bday = new Date(birthday);
    const endDate = new Date(bday.getTime() + 80 * 365.25 * 24 * 60 * 60 * 1000);
    const now = new Date();
    const remainingMs = Math.max(0, endDate.getTime() - now.getTime());
    const totalSec = Math.floor(remainingMs / 1000);
    const days = Math.floor(totalSec / 86400);
    const hours = Math.floor((totalSec % 86400) / 3600);
    const minutes = Math.floor((totalSec % 3600) / 60);
    const seconds = totalSec % 60;
    return {
      days: days.toLocaleString(),
      hours: hours.toString().padStart(2, "0"),
      minutes: minutes.toString().padStart(2, "0"),
      seconds: seconds.toString().padStart(2, "0"),
    };
  }, [birthday]);

  useEffect(() => {
    setTimeLeft(compute());
    intervalRef.current = setInterval(() => {
      setTimeLeft(compute());
    }, 1000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [compute]);

  return (
    <View style={[styles.liveCountdownCard, { backgroundColor: colors.peachLight + "30" }]}>
      <View style={styles.liveCountdownRow}>
        <View style={styles.timeUnit}>
          <TickingDigit value={timeLeft.days} colors={colors} />
          <Text style={[styles.timeLabel, { color: colors.textMuted }]}>{t("remainingDays")}</Text>
        </View>
        <Text style={[styles.timeSeparator, { color: colors.textMuted }]}>:</Text>
        <View style={styles.timeUnit}>
          <TickingDigit value={timeLeft.hours} colors={colors} />
          <Text style={[styles.timeLabel, { color: colors.textMuted }]}>{t("remainingHours")}</Text>
        </View>
        <Text style={[styles.timeSeparator, { color: colors.textMuted }]}>:</Text>
        <View style={styles.timeUnit}>
          <TickingDigit value={timeLeft.minutes} colors={colors} />
          <Text style={[styles.timeLabel, { color: colors.textMuted }]}>{t("remainingMinutes")}</Text>
        </View>
        <Text style={[styles.timeSeparator, { color: colors.textMuted }]}>:</Text>
        <View style={styles.timeUnit}>
          <TickingDigit value={timeLeft.seconds} colors={colors} />
          <Text style={[styles.timeLabel, { color: colors.textMuted }]}>{t("remainingSeconds")}</Text>
        </View>
      </View>
    </View>
  );
}

function CheckInToast({ daysLived, onClose, colors }: { daysLived: number; onClose: () => void; colors: any }) {
  const { t } = useI18n();
  const scale = useSharedValue(0);
  const opacity = useSharedValue(0);

  useEffect(() => {
    opacity.value = withTiming(1, { duration: 300 });
    scale.value = withSpring(1, { damping: 12, stiffness: 150 });
    const timer = setTimeout(() => {
      opacity.value = withTiming(0, { duration: 400 });
      scale.value = withTiming(0.8, { duration: 400 });
      setTimeout(onClose, 500);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: opacity.value,
  }));

  return (
    <Modal visible transparent animationType="none">
      <Pressable style={styles.toastOverlay} onPress={onClose}>
        <Animated.View style={[styles.toastCard, animStyle]}>
          <LinearGradient
            colors={[colors.peachLight, colors.peach, colors.peachLight]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.toastGradient}
          >
            <Ionicons name="sparkles" size={24} color={colors.coral} />
            <Text style={[styles.toastText, { color: colors.coral }]}>
              {t("survivedDays")} {daysLived.toLocaleString()} {t("survivedDaysSuffix")}
            </Text>
            <Ionicons name="sparkles" size={24} color={colors.coral} />
          </LinearGradient>
        </Animated.View>
      </Pressable>
    </Modal>
  );
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const colors = useThemeColors();
  const { user, birthday, checkedInToday, streak, checkIn, birthdayLocked, todayMood } = useApp();
  const { t, lang } = useI18n();
  const webTopInset = Platform.OS === "web" ? 67 : 0;
  const [showCheckinToast, setShowCheckinToast] = useState(false);

  const fadeIn = useSharedValue(0);
  const slideUp = useSharedValue(30);

  useEffect(() => {
    if (!user) {
      router.replace("/login");
      return;
    }
    fadeIn.value = withTiming(1, { duration: 800 });
    slideUp.value = withSpring(0, { damping: 20 });
  }, [user]);

  const containerAnim = useAnimatedStyle(() => ({
    opacity: fadeIn.value,
    transform: [{ translateY: slideUp.value }],
  }));

  const stats = birthday ? calculateLifeStats(birthday) : null;
  const dailyQuote = getDailyQuote();
  const marqueeContent = user ? `${user.username} ${t("marqueeText")}` : "";

  const handleCheckIn = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await checkIn();
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowCheckinToast(true);
  };

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return t("goodMorning");
    if (hour < 18) return t("goodAfternoon");
    return t("goodEvening");
  };

  const moodLabelsMap: Record<string, string> = {
    happy: t("moodHappy"),
    normal: t("moodNormal"),
    down: t("moodDown"),
    anxious: t("moodAnxious"),
    tired: t("moodTired"),
  };

  const handleShare = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const weekends = stats?.remainingWeekends?.toLocaleString() || "---";
    const mood = todayMood ? moodLabelsMap[todayMood.mood] || t("noMoodYet") : t("noMoodYet");
    const slogan = t("shareBrandSlogan");
    const message = `${t("shareTitle")}\n\n${t("shareWeekends")}: ${weekends}\n${t("shareMood")}: ${mood}\n\n${slogan}`;
    try {
      await Share.share({ message });
    } catch {}
  };

  if (!user) return null;

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientMid, colors.gradientEnd]}
      style={styles.screen}
      start={{ x: 0, y: 0 }}
      end={{ x: 0.5, y: 1 }}
    >
      <FloatingTexts />
      <ScrollView
        style={styles.screen}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: insets.top + webTopInset + 12,
            paddingBottom: insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <MarqueeBanner text={marqueeContent} />

        <Animated.View style={[styles.container, containerAnim]}>
          <View style={styles.greetingRow}>
            <View style={styles.greetingSection}>
              <Text style={[styles.greeting, { color: colors.textPrimary }]}>
                {greeting()}{lang === "zh" ? "\uFF0C" : ", "}{user.username}
              </Text>
              <Text style={[styles.greetingSubtitle, { color: colors.textSecondary }]}>
                {t("liveWellToday")}
              </Text>
            </View>
            <Pressable
              onPress={handleShare}
              style={({ pressed }) => [
                styles.shareButton,
                pressed && { opacity: 0.7, transform: [{ scale: 0.95 }] },
              ]}
              hitSlop={8}
            >
              <Ionicons name="share-outline" size={20} color={colors.coral} />
            </Pressable>
          </View>

          {!birthday ? (
            <Pressable
              onPress={() => router.push("/birthday")}
              style={({ pressed }) => [
                styles.setupCard,
                { backgroundColor: colors.cardBg },
                pressed && { transform: [{ scale: 0.98 }], opacity: 0.9 },
              ]}
            >
              <View style={styles.setupIconCircle}>
                <Ionicons name="hourglass-outline" size={32} color={colors.coral} />
              </View>
              <Text style={[styles.setupTitle, { color: colors.textPrimary }]}>{t("setBirthday")}</Text>
              <Text style={[styles.setupSubtitle, { color: colors.textSecondary }]}>
                {t("openCountdown")}
              </Text>
              <View style={styles.setupArrow}>
                <Ionicons name="arrow-forward" size={20} color={colors.coral} />
              </View>
            </Pressable>
          ) : stats ? (
            <View style={[styles.countdownCard, { backgroundColor: colors.cardBg }]}>
              <View style={styles.ringContainer}>
                <ProgressRing progress={stats.progressPercent} size={160} strokeWidth={12} colors={colors} />
                <View style={styles.ringCenter}>
                  <Text style={[styles.ringPercent, { color: colors.textPrimary }]}>
                    {stats.progressPercent.toFixed(1)}%
                  </Text>
                  <Text style={[styles.ringLabel, { color: colors.textMuted }]}>{t("alreadyPassed")}</Text>
                  <Text style={[styles.ringRemainingYears, { color: colors.coral }]}>
                    {lang === "zh" ? `剩餘 ${stats.remainingYears} 年` : `${stats.remainingYears} yrs left`}
                  </Text>
                </View>
              </View>

              <LiveCountdownTimer birthday={birthday} colors={colors} />

              <View style={styles.ageRow}>
                <Ionicons name="time-outline" size={15} color={colors.textMuted} />
                <Text style={[styles.ageText, { color: colors.textMuted }]}>
                  {t("lived")} {stats.ageYears}{t("year")} {stats.ageMonths}{t("month")} {stats.ageDays}{t("day")}
                </Text>
              </View>

              {!birthdayLocked && (
                <Pressable
                  onPress={() => router.push("/birthday")}
                  style={styles.editBirthdayBtn}
                  hitSlop={8}
                >
                  <Ionicons name="create-outline" size={14} color={colors.textMuted} />
                  <Text style={[styles.editBirthdayText, { color: colors.textMuted }]}>{t("editBirthday")}</Text>
                </Pressable>
              )}
            </View>
          ) : null}

          <View style={[styles.quoteCard, { backgroundColor: colors.cardBg, borderLeftColor: colors.gold }]}>
            <View style={styles.quoteHeader}>
              <Ionicons name="sparkles-outline" size={16} color={colors.gold} />
              <Text style={[styles.quoteLabel, { color: colors.gold }]}>{t("dailyCard")}</Text>
            </View>
            <Text style={[styles.quoteText, { color: colors.textPrimary }]}>
              {lang === "zh" ? dailyQuote.zh : dailyQuote.en}
            </Text>
            <Text style={[styles.quoteAuthor, { color: colors.textMuted }]}>
              {"— "}{lang === "zh" ? dailyQuote.author_zh : dailyQuote.author_en}
            </Text>
          </View>

          <View style={styles.checkinSection}>
            <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>{t("dailyCheckin")}</Text>
            {checkedInToday ? (
              <View style={[styles.checkedInCard, { backgroundColor: colors.cardBg, borderColor: colors.sageLight }]}>
                <View style={styles.checkedInIcon}>
                  <Ionicons name="checkmark-circle" size={44} color={colors.sage} />
                </View>
                <Text style={[styles.checkedInText, { color: colors.sage }]}>{t("checkedInToday")}</Text>
                <Text style={[styles.checkedInSubtext, { color: colors.textSecondary }]}>
                  {t("consecutiveCheckin")} {streak} {t("days")}
                </Text>
              </View>
            ) : (
              <Pressable
                onPress={handleCheckIn}
                style={({ pressed }) => [
                  styles.checkinButton,
                  { backgroundColor: colors.cardBg, borderColor: colors.peachLight },
                  pressed && { transform: [{ scale: 0.96 }] },
                ]}
              >
                <View style={styles.checkinInner}>
                  <Ionicons name="sunny-outline" size={34} color={colors.coral} />
                  <Text style={[styles.checkinMainText, { color: colors.coral }]}>{t("imOkayToday")}</Text>
                  <Text style={[styles.checkinHint, { color: colors.textMuted }]}>{t("tapToCheckin")}</Text>
                </View>
              </Pressable>
            )}
            {streak > 0 && !checkedInToday && (
              <Text style={[styles.streakReminder, { color: colors.gold }]}>
                {t("consecutiveReminder1")} {streak} {t("consecutiveReminder2")}
              </Text>
            )}
          </View>
        </Animated.View>
      </ScrollView>

      {showCheckinToast && stats && (
        <CheckInToast
          daysLived={stats.daysLived}
          onClose={() => setShowCheckinToast(false)}
          colors={colors}
        />
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  scrollContent: { flexGrow: 1 },
  container: {
    paddingHorizontal: 20,
    gap: 20,
  },
  greetingRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
  greetingSection: {
    gap: 4,
    flex: 1,
  },
  greeting: {
    fontSize: 26,
    fontFamily: "NotoSansTC_700Bold",
  },
  greetingSubtitle: {
    fontSize: 15,
    fontFamily: "NotoSansTC_400Regular",
  },
  shareButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(232, 145, 110, 0.1)",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 4,
  },
  setupCard: {
    borderRadius: 20,
    padding: 28,
    alignItems: "center",
    gap: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 16,
    elevation: 3,
  },
  setupIconCircle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: "rgba(232, 145, 110, 0.1)",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  setupTitle: {
    fontSize: 18,
    fontFamily: "NotoSansTC_700Bold",
  },
  setupSubtitle: {
    fontSize: 14,
    fontFamily: "NotoSansTC_400Regular",
  },
  setupArrow: {
    marginTop: 8,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "rgba(232, 145, 110, 0.1)",
    alignItems: "center",
    justifyContent: "center",
  },
  countdownCard: {
    borderRadius: 24,
    padding: 24,
    alignItems: "center",
    gap: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.07,
    shadowRadius: 16,
    elevation: 4,
  },
  ringContainer: {
    alignItems: "center",
    justifyContent: "center",
  },
  ringCenter: {
    position: "absolute",
    alignItems: "center",
    gap: 2,
  },
  ringPercent: {
    fontSize: 26,
    fontFamily: "NotoSansTC_700Bold",
  },
  ringLabel: {
    fontSize: 12,
    fontFamily: "NotoSansTC_400Regular",
  },
  ringRemainingYears: {
    fontSize: 11,
    fontFamily: "NotoSansTC_500Medium",
    marginTop: 2,
  },
  liveCountdownCard: {
    width: "100%",
    borderRadius: 16,
    paddingVertical: 12,
    paddingHorizontal: 8,
  },
  liveCountdownRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
  },
  timeUnit: {
    alignItems: "center",
    minWidth: 48,
  },
  timeValue: {
    fontSize: 18,
    fontFamily: "NotoSansTC_700Bold",
  },
  timeLabel: {
    fontSize: 9,
    fontFamily: "NotoSansTC_400Regular",
    marginTop: 2,
  },
  timeSeparator: {
    fontSize: 18,
    fontFamily: "NotoSansTC_700Bold",
    marginBottom: 14,
  },
  ageRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  ageText: {
    fontSize: 13,
    fontFamily: "NotoSansTC_400Regular",
  },
  editBirthdayBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  editBirthdayText: {
    fontSize: 12,
    fontFamily: "NotoSansTC_400Regular",
  },
  quoteCard: {
    borderRadius: 20,
    padding: 22,
    gap: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 12,
    elevation: 2,
    borderLeftWidth: 4,
  },
  quoteHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  quoteLabel: {
    fontSize: 13,
    fontFamily: "NotoSansTC_500Medium",
  },
  quoteText: {
    fontSize: 15,
    fontFamily: "NotoSansTC_400Regular",
    lineHeight: 26,
  },
  quoteAuthor: {
    fontSize: 12,
    fontFamily: "NotoSansTC_400Regular",
    textAlign: "right",
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: "NotoSansTC_700Bold",
    marginBottom: 4,
  },
  checkinSection: {
    gap: 12,
  },
  checkedInCard: {
    borderRadius: 20,
    padding: 24,
    alignItems: "center",
    gap: 8,
    borderWidth: 1.5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  checkedInIcon: {
    marginBottom: 4,
  },
  checkedInText: {
    fontSize: 17,
    fontFamily: "NotoSansTC_700Bold",
  },
  checkedInSubtext: {
    fontSize: 14,
    fontFamily: "NotoSansTC_400Regular",
  },
  checkinButton: {
    borderRadius: 20,
    borderWidth: 2,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  checkinInner: {
    padding: 24,
    alignItems: "center",
    gap: 8,
  },
  checkinMainText: {
    fontSize: 19,
    fontFamily: "NotoSansTC_700Bold",
  },
  checkinHint: {
    fontSize: 13,
    fontFamily: "NotoSansTC_400Regular",
  },
  streakReminder: {
    fontSize: 13,
    fontFamily: "NotoSansTC_400Regular",
    textAlign: "center",
  },
  toastOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(0,0,0,0.2)",
  },
  toastCard: {
    borderRadius: 20,
    overflow: "hidden",
    shadowColor: "#E8916E",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 8,
  },
  toastGradient: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingVertical: 24,
    paddingHorizontal: 32,
    borderRadius: 20,
  },
  toastText: {
    fontSize: 18,
    fontFamily: "NotoSansTC_700Bold",
    letterSpacing: 0.5,
  },
});
