import React, { useState } from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  Platform,
  TextInput,
  ScrollView,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { useThemeColors } from "@/lib/ThemeContext";
import { useApp } from "@/lib/AppContext";
import { useI18n } from "@/lib/i18n";

export default function BirthdayScreen() {
  const insets = useSafeAreaInsets();
  const colors = useThemeColors();
  const { setBirthday, birthdayLocked, birthday } = useApp();
  const { t } = useI18n();
  const [year, setYear] = useState("");
  const [month, setMonth] = useState("");
  const [day, setDay] = useState("");
  const [error, setError] = useState("");

  const webTopInset = Platform.OS === "web" ? 67 : 0;

  if (birthdayLocked && birthday) {
    return (
      <LinearGradient
        colors={[colors.gradientStart, colors.gradientMid, colors.gradientEnd]}
        style={styles.flex}
        start={{ x: 0, y: 0 }}
        end={{ x: 0.5, y: 1 }}
      >
        <View
          style={[
            styles.container,
            {
              paddingTop: insets.top + webTopInset + 20,
              paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 20),
            },
          ]}
        >
          <View style={styles.header}>
            <Pressable onPress={() => router.back()} hitSlop={16}>
              <Ionicons name="close" size={28} color={colors.textPrimary} />
            </Pressable>
          </View>
          <View style={styles.lockedContent}>
            <View style={[styles.lockIconCircle, { backgroundColor: colors.border }]}>
              <Ionicons name="lock-closed" size={40} color={colors.textMuted} />
            </View>
            <Text style={[styles.lockedTitle, { color: colors.textPrimary }]}>{t("birthdayLocked")}</Text>
            <Text style={[styles.lockedSubtitle, { color: colors.textSecondary }]}>{t("birthdayLockNote")}</Text>
            <View style={[styles.currentBirthdayCard, { backgroundColor: colors.cardBg }]}>
              <Ionicons name="calendar" size={20} color={colors.coral} />
              <Text style={[styles.currentBirthdayText, { color: colors.coral }]}>{birthday}</Text>
            </View>
          </View>
        </View>
      </LinearGradient>
    );
  }

  const validate = (): boolean => {
    const y = parseInt(year);
    const m = parseInt(month);
    const d = parseInt(day);
    if (!y || !m || !d) {
      setError(t("fillComplete"));
      return false;
    }
    if (y < 1920 || y > new Date().getFullYear()) {
      setError(t("invalidYear"));
      return false;
    }
    if (m < 1 || m > 12) {
      setError(t("invalidMonth"));
      return false;
    }
    if (d < 1 || d > 31) {
      setError(t("invalidDay"));
      return false;
    }
    const date = new Date(y, m - 1, d);
    if (date > new Date()) {
      setError(t("birthdayNotFuture"));
      return false;
    }
    setError("");
    return true;
  };

  const handleSave = async () => {
    if (!validate()) return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const dateStr = `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    await setBirthday(dateStr);
    router.back();
  };

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientMid, colors.gradientEnd]}
      style={styles.flex}
      start={{ x: 0, y: 0 }}
      end={{ x: 0.5, y: 1 }}
    >
      <View
        style={[
          styles.container,
          {
            paddingTop: insets.top + webTopInset + 20,
            paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 20),
          },
        ]}
      >
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} hitSlop={16}>
            <Ionicons name="close" size={28} color={colors.textPrimary} />
          </Pressable>
        </View>

        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View style={[styles.iconCircle, { backgroundColor: "rgba(232, 145, 110, 0.12)" }]}>
            <Ionicons name="calendar-outline" size={36} color={colors.coral} />
          </View>
          <Text style={[styles.title, { color: colors.textPrimary }]}>{t("birthdaySetTitle")}</Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            {t("birthdayCalcNote")}
          </Text>

          <View style={styles.dateRow}>
            <View style={styles.dateFieldWide}>
              <Text style={[styles.dateLabel, { color: colors.textSecondary }]}>{t("yearLabel")}</Text>
              <TextInput
                testID="birthday-year"
                style={[styles.dateInput, { backgroundColor: colors.cardBg, borderColor: colors.border, color: colors.textPrimary }]}
                placeholder="1990"
                placeholderTextColor={colors.textMuted}
                value={year}
                onChangeText={(txt) => { setYear(txt.replace(/[^0-9]/g, "")); setError(""); }}
                keyboardType="number-pad"
                maxLength={4}
              />
            </View>
            <View style={styles.dateField}>
              <Text style={[styles.dateLabel, { color: colors.textSecondary }]}>{t("monthLabel")}</Text>
              <TextInput
                testID="birthday-month"
                style={[styles.dateInput, { backgroundColor: colors.cardBg, borderColor: colors.border, color: colors.textPrimary }]}
                placeholder="01"
                placeholderTextColor={colors.textMuted}
                value={month}
                onChangeText={(txt) => { setMonth(txt.replace(/[^0-9]/g, "")); setError(""); }}
                keyboardType="number-pad"
                maxLength={2}
              />
            </View>
            <View style={styles.dateField}>
              <Text style={[styles.dateLabel, { color: colors.textSecondary }]}>{t("dayLabel")}</Text>
              <TextInput
                testID="birthday-day"
                style={[styles.dateInput, { backgroundColor: colors.cardBg, borderColor: colors.border, color: colors.textPrimary }]}
                placeholder="01"
                placeholderTextColor={colors.textMuted}
                value={day}
                onChangeText={(txt) => { setDay(txt.replace(/[^0-9]/g, "")); setError(""); }}
                keyboardType="number-pad"
                maxLength={2}
              />
            </View>
          </View>

          {!!error && (
            <Text style={styles.errorText}>{error}</Text>
          )}

          <Pressable
            testID="birthday-confirm"
            onPress={handleSave}
            style={({ pressed }) => [
              styles.saveButton,
              { backgroundColor: colors.coral },
              pressed && { transform: [{ scale: 0.97 }], opacity: 0.9 },
            ]}
          >
            <Ionicons name="checkmark" size={22} color="#FFF" />
            <Text style={styles.saveButtonText}>{t("confirm")}</Text>
          </Pressable>
        </ScrollView>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "flex-end",
    paddingHorizontal: 20,
    paddingBottom: 8,
  },
  content: {
    alignItems: "center",
    paddingHorizontal: 32,
    paddingTop: 32,
    gap: 16,
  },
  iconCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  title: {
    fontSize: 24,
    fontFamily: "NotoSansTC_700Bold",
  },
  subtitle: {
    fontSize: 14,
    fontFamily: "NotoSansTC_400Regular",
    textAlign: "center",
    lineHeight: 22,
  },
  dateRow: {
    flexDirection: "row",
    gap: 12,
    marginTop: 16,
    width: "100%",
  },
  dateField: {
    flex: 1,
    gap: 6,
  },
  dateFieldWide: {
    flex: 1.5,
    gap: 6,
  },
  dateLabel: {
    fontSize: 13,
    fontFamily: "NotoSansTC_500Medium",
    marginLeft: 4,
  },
  dateInput: {
    borderRadius: 14,
    borderWidth: 1.5,
    height: 52,
    paddingHorizontal: 16,
    fontSize: 18,
    fontFamily: "NotoSansTC_500Medium",
    textAlign: "center",
  },
  errorText: {
    fontSize: 13,
    fontFamily: "NotoSansTC_400Regular",
    color: "#E85D4A",
    marginTop: 4,
  },
  saveButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 16,
    height: 52,
    width: "100%",
    gap: 8,
    marginTop: 16,
    shadowColor: "#E8916E",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  saveButtonText: {
    fontSize: 17,
    fontFamily: "NotoSansTC_700Bold",
    color: "#FFF",
  },
  lockedContent: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
    gap: 16,
  },
  lockIconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  lockedTitle: {
    fontSize: 22,
    fontFamily: "NotoSansTC_700Bold",
  },
  lockedSubtitle: {
    fontSize: 14,
    fontFamily: "NotoSansTC_400Regular",
    textAlign: "center",
    lineHeight: 22,
  },
  currentBirthdayCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 16,
    marginTop: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  currentBirthdayText: {
    fontSize: 18,
    fontFamily: "NotoSansTC_700Bold",
  },
});
