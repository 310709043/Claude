import React from "react";
import { View, Text, StyleSheet, Modal, Pressable, Platform } from "react-native";
import { BlurView } from "expo-blur";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/lib/ThemeContext";
import { useI18n } from "@/lib/i18n";

interface Props {
  visible: boolean;
  onClose: () => void;
}

interface Feature {
  icon: keyof typeof Ionicons.glyphMap;
  zh: string;
  en: string;
}

const UPCOMING_FEATURES: Feature[] = [
  { icon: "sparkles-outline", zh: "每日心靈卡升級為塔羅牌語錄", en: "Daily card upgraded to tarot quotes" },
  { icon: "mail-outline", zh: "無限未來信", en: "Unlimited future letters" },
  { icon: "create-outline", zh: "完整情緒日記（文字不限）", en: "Full mood diary (unlimited text)" },
  { icon: "analytics-outline", zh: "AI人生回顧（30天情緒分析）", en: "AI life review (30-day mood analysis)" },
  { icon: "time-outline", zh: "1封未來信", en: "1 future letter" },
  { icon: "alert-circle-outline", zh: "緊急通知", en: "Emergency alerts" },
];

export default function UpcomingFeaturesModal({ visible, onClose }: Props) {
  const { mode, colors } = useTheme();
  const { lang } = useI18n();
  const isIOS = Platform.OS === "ios";
  const isWeb = Platform.OS === "web";

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.overlay}>
        {!isWeb ? (
          <BlurView
            intensity={40}
            tint={mode === "dark" ? "dark" : "light"}
            style={StyleSheet.absoluteFill}
          />
        ) : (
          <View style={[StyleSheet.absoluteFill, styles.webBlur]} />
        )}
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View style={[styles.card, { backgroundColor: colors.cardBg }]}>
          <Pressable onPress={onClose} style={styles.closeBtn} hitSlop={12}>
            <Ionicons name="close" size={22} color={colors.textMuted} />
          </Pressable>

          <View style={[styles.iconCircle, { backgroundColor: "rgba(212, 165, 116, 0.12)" }]}>
            <Ionicons name="rocket-outline" size={28} color={colors.gold} />
          </View>

          <Text style={[styles.title, { color: colors.textPrimary }]}>
            {lang === "zh" ? "繼續優化中" : "Coming Soon"}
          </Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            {lang === "zh" ? "以下功能正在開發中..." : "These features are in development..."}
          </Text>

          <View style={styles.featureList}>
            {UPCOMING_FEATURES.map((feature, i) => (
              <View key={i} style={styles.featureRow}>
                <View style={[styles.featureIconBg, { backgroundColor: colors.gold + "15" }]}>
                  <Ionicons name={feature.icon} size={18} color={colors.gold} />
                </View>
                <View style={styles.featureTextWrap}>
                  {isIOS ? (
                    <BlurView intensity={12} tint={mode === "dark" ? "dark" : "light"} style={styles.featureBlur}>
                      <Text style={[styles.featureText, { color: colors.textPrimary }]}>
                        {lang === "zh" ? feature.zh : feature.en}
                      </Text>
                    </BlurView>
                  ) : (
                    <View style={[styles.featureBlurFallback, { backgroundColor: colors.background + "CC" }]}>
                      <Text style={[styles.featureText, { color: colors.textPrimary, opacity: 0.35 }]}>
                        {lang === "zh" ? feature.zh : feature.en}
                      </Text>
                    </View>
                  )}
                </View>
              </View>
            ))}
          </View>

          <Text style={[styles.mysteryHint, { color: colors.textMuted }]}>
            {lang === "zh" ? "敬請期待 ..." : "Stay tuned ..."}
          </Text>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 24,
  },
  webBlur: {
    backgroundColor: "rgba(0,0,0,0.35)",
  },
  card: {
    borderRadius: 24,
    padding: 28,
    alignItems: "center",
    gap: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 20,
    elevation: 8,
    width: "100%",
    maxWidth: 360,
  },
  closeBtn: {
    position: "absolute",
    top: 16,
    right: 16,
    zIndex: 1,
  },
  iconCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 20,
    fontFamily: "NotoSansTC_700Bold",
  },
  subtitle: {
    fontSize: 13,
    fontFamily: "NotoSansTC_400Regular",
  },
  featureList: {
    width: "100%",
    gap: 10,
    marginTop: 4,
  },
  featureRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  featureIconBg: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  featureTextWrap: {
    flex: 1,
    borderRadius: 10,
    overflow: "hidden",
  },
  featureBlur: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
    overflow: "hidden",
  },
  featureBlurFallback: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
  },
  featureText: {
    fontSize: 14,
    fontFamily: "NotoSansTC_500Medium",
  },
  mysteryHint: {
    fontSize: 13,
    fontFamily: "NotoSansTC_400Regular",
    marginTop: 4,
    fontStyle: "italic",
  },
});
