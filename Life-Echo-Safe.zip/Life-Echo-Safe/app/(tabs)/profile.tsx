import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  Platform,
  ScrollView,
  Alert,
  Image,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
} from "react-native-reanimated";
import { LinearGradient } from "expo-linear-gradient";
import { useThemeColors } from "@/lib/ThemeContext";
import { useApp } from "@/lib/AppContext";
import { useI18n } from "@/lib/i18n";
import { getRecentMoods } from "@/lib/storage";
import MarqueeBanner from "@/components/MarqueeBanner";
import SupportModal from "@/components/SupportModal";
import UpcomingFeaturesModal from "@/components/UpcomingFeaturesModal";
import FloatingTexts from "@/components/FloatingTexts";

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const colors = useThemeColors();
  const { user, birthday, streak, moods, logout, birthdayLocked, avatarUri, setAvatar } = useApp();
  const { t, lang, toggleLang } = useI18n();
  const webTopInset = Platform.OS === "web" ? 67 : 0;
  const [showSupport, setShowSupport] = useState(false);
  const [showUpcoming, setShowUpcoming] = useState(false);

  const fadeIn = useSharedValue(0);
  useEffect(() => {
    if (!user) {
      router.replace("/login");
      return;
    }
    fadeIn.value = withTiming(1, { duration: 600 });
  }, [user]);

  const containerAnim = useAnimatedStyle(() => ({ opacity: fadeIn.value }));

  const stats = useMemo(() => {
    const totalMoods = moods.length;
    const recentMoods = getRecentMoods(moods, 30);
    const moodCounts: Record<string, number> = {};
    recentMoods.forEach((m) => {
      moodCounts[m.mood] = (moodCounts[m.mood] || 0) + 1;
    });
    const topMood = Object.entries(moodCounts).sort((a, b) => b[1] - a[1])[0];
    return { totalMoods, topMood: topMood?.[0] || null };
  }, [moods]);

  const moodLabelsMap: Record<string, string> = {
    happy: t("moodHappy"),
    normal: t("moodNormal"),
    down: t("moodDown"),
    anxious: t("moodAnxious"),
    tired: t("moodTired"),
  };

  const handleLogout = () => {
    const doLogout = async () => {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      await logout();
      router.replace("/login");
    };

    if (Platform.OS === "web") {
      if (confirm(t("logoutConfirm"))) {
        doLogout();
      }
    } else {
      Alert.alert(
        t("logout"),
        t("logoutConfirm"),
        [
          { text: t("cancel"), style: "cancel" },
          { text: t("confirm"), style: "destructive", onPress: doLogout },
        ]
      );
    }
  };

  const handleToggleLang = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    toggleLang();
  };

  const handlePickAvatar = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });
      if (!result.canceled && result.assets[0]) {
        await setAvatar(result.assets[0].uri);
      }
    } catch {}
  };

  if (!user) return null;

  const marqueeContent = `${user.username} ${t("marqueeText")}`;

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientMid, colors.gradientEnd]}
      style={styles.screen}
      start={{ x: 0, y: 0 }}
      end={{ x: 0.5, y: 1 }}
    >
      <FloatingTexts />
      <ScrollView
        style={styles.screen}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: insets.top + webTopInset + 8,
            paddingBottom: insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <MarqueeBanner text={marqueeContent} />

        <Animated.View style={[styles.container, containerAnim]}>
          <View style={styles.profileHeader}>
            <Pressable
              onPress={handlePickAvatar}
              style={({ pressed }) => [pressed && { opacity: 0.8 }]}
            >
              {avatarUri ? (
                <Image source={{ uri: avatarUri }} style={styles.avatarImage} />
              ) : (
                <View style={[styles.avatarCircle, { backgroundColor: colors.peachLight }]}>
                  <Text style={[styles.avatarText, { color: colors.coral }]}>
                    {user.username.charAt(0).toUpperCase()}
                  </Text>
                </View>
              )}
              <View style={[styles.avatarEditBadge, { backgroundColor: colors.coral, borderColor: colors.cardBg }]}>
                <Ionicons name="camera" size={12} color="#FFF" />
              </View>
            </Pressable>
            <Text style={[styles.avatarHint, { color: colors.textMuted }]}>{t("uploadAvatar")}</Text>
            <Text style={[styles.username, { color: colors.textPrimary }]}>{user.username}</Text>
            <Text style={[styles.joinDate, { color: colors.textMuted }]}>
              {t("joinedOn")} {new Date(user.createdAt).toLocaleDateString(lang === "zh" ? "zh-TW" : "en-US")}
            </Text>
          </View>

          <View style={styles.statsRow}>
            <View style={[styles.statBox, { backgroundColor: colors.cardBg }]}>
              <Text style={[styles.statNumber, { color: colors.coral }]}>{streak}</Text>
              <Text style={[styles.statText, { color: colors.textMuted }]}>{t("consecutiveCheckinLabel")}</Text>
            </View>
            <View style={[styles.statBox, { backgroundColor: colors.cardBg }]}>
              <Text style={[styles.statNumber, { color: colors.coral }]}>{stats.totalMoods}</Text>
              <Text style={[styles.statText, { color: colors.textMuted }]}>{t("totalRecords")}</Text>
            </View>
            <View style={[styles.statBox, { backgroundColor: colors.cardBg }]}>
              <Text style={[styles.statNumber, { color: colors.coral }]}>
                {stats.topMood ? moodLabelsMap[stats.topMood] : "-"}
              </Text>
              <Text style={[styles.statText, { color: colors.textMuted }]}>{t("topMood")}</Text>
            </View>
          </View>

          <View style={[styles.menuCard, { backgroundColor: colors.cardBg }]}>
            <Pressable
              onPress={() => {
                if (birthdayLocked && birthday) {
                  if (Platform.OS === "web") {
                    alert(t("birthdayLockNote"));
                  } else {
                    Alert.alert(t("birthdayLocked"), t("birthdayLockNote"));
                  }
                  return;
                }
                router.push("/birthday");
              }}
              style={({ pressed }) => [
                styles.menuItem,
                pressed && { backgroundColor: colors.peachLight + "33" },
              ]}
            >
              <View style={[styles.menuIcon, { backgroundColor: "rgba(232, 145, 110, 0.1)" }]}>
                <Ionicons name="calendar-outline" size={20} color={colors.coral} />
              </View>
              <Text style={[styles.menuLabel, { color: colors.textPrimary }]}>{t("editBirthday")}</Text>
              <View style={styles.menuRight}>
                {birthday && (
                  <Text style={[styles.menuValue, { color: colors.textMuted }]}>{birthday}</Text>
                )}
                {birthdayLocked && birthday ? (
                  <Ionicons name="lock-closed" size={16} color={colors.textMuted} />
                ) : (
                  <Ionicons name="chevron-forward" size={18} color={colors.textMuted} />
                )}
              </View>
            </Pressable>

            <View style={[styles.menuDivider, { backgroundColor: colors.border }]} />

            <Pressable
              onPress={handleToggleLang}
              style={({ pressed }) => [
                styles.menuItem,
                pressed && { backgroundColor: "rgba(141, 186, 212, 0.08)" },
              ]}
            >
              <View style={[styles.menuIcon, { backgroundColor: "rgba(141, 186, 212, 0.12)" }]}>
                <Ionicons name="language-outline" size={20} color={colors.sky} />
              </View>
              <Text style={[styles.menuLabel, { color: colors.textPrimary }]}>{t("language")}</Text>
              <View style={styles.menuRight}>
                <Text style={[styles.menuValue, { color: colors.textMuted }]}>
                  {lang === "zh" ? t("languageZh") : t("languageEn")}
                </Text>
                <Ionicons name="swap-horizontal" size={18} color={colors.textMuted} />
              </View>
            </Pressable>

            <View style={[styles.menuDivider, { backgroundColor: colors.border }]} />

            <Pressable
              onPress={handleLogout}
              style={({ pressed }) => [
                styles.menuItem,
                pressed && { backgroundColor: "rgba(232, 93, 74, 0.05)" },
              ]}
            >
              <View style={[styles.menuIcon, { backgroundColor: "rgba(232, 93, 74, 0.1)" }]}>
                <Ionicons name="log-out-outline" size={20} color="#E85D4A" />
              </View>
              <Text style={[styles.menuLabel, { color: "#E85D4A" }]}>{t("logout")}</Text>
              <View style={styles.menuRight}>
                <Ionicons name="chevron-forward" size={18} color={colors.textMuted} />
              </View>
            </Pressable>
          </View>

          <View style={styles.supportGroup}>
            <Pressable
              onPress={async () => {
                await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setShowSupport(true);
              }}
              style={({ pressed }) => [
                styles.supportRow,
                { backgroundColor: colors.cardBg },
                pressed && { opacity: 0.85 },
              ]}
            >
              <Ionicons name="cafe-outline" size={18} color={colors.coral} />
              <Text style={[styles.supportRowText, { color: colors.textSecondary }]}>
                {t("supportCompact")}
              </Text>
              <Ionicons name="chevron-forward" size={16} color={colors.textMuted} />
            </Pressable>

            <Pressable
              onPress={async () => {
                await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setShowUpcoming(true);
              }}
              style={({ pressed }) => [
                styles.supportRow,
                { backgroundColor: colors.cardBg },
                pressed && { opacity: 0.85 },
              ]}
            >
              <Ionicons name="rocket-outline" size={18} color={colors.gold} />
              <Text style={[styles.supportRowText, { color: colors.textSecondary }]}>
                {lang === "zh" ? "繼續優化中" : "Coming Soon"}
              </Text>
              <Ionicons name="chevron-forward" size={16} color={colors.textMuted} />
            </Pressable>
          </View>

          <View style={styles.footerSection}>
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <MaterialCommunityIcons name="notebook-outline" size={18} color={colors.gold} />
              <Ionicons name="leaf" size={13} color={colors.sage} style={{ marginLeft: -3, marginTop: -6, transform: [{ rotate: "-30deg" }] }} />
            </View>
            <Text style={[styles.footerText, { color: colors.textMuted }]}>
              {lang === "zh" ? "\u9918\u751F\u8A18 Life Echo" : "Life Echo"}
            </Text>
            <Text style={[styles.footerVersion, { color: colors.textMuted }]}>{t("version")}</Text>
          </View>
        </Animated.View>
      </ScrollView>

      <SupportModal visible={showSupport} onClose={() => setShowSupport(false)} />
      <UpcomingFeaturesModal visible={showUpcoming} onClose={() => setShowUpcoming(false)} />
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  scrollContent: { flexGrow: 1 },
  container: {
    paddingHorizontal: 20,
    gap: 24,
  },
  profileHeader: {
    alignItems: "center",
    gap: 6,
    paddingVertical: 12,
  },
  avatarCircle: {
    width: 88,
    height: 88,
    borderRadius: 44,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#E8916E",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 4,
  },
  avatarImage: {
    width: 88,
    height: 88,
    borderRadius: 44,
  },
  avatarText: {
    fontSize: 34,
    fontFamily: "NotoSansTC_700Bold",
  },
  avatarEditBadge: {
    position: "absolute",
    bottom: 0,
    right: 0,
    width: 26,
    height: 26,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
  },
  avatarHint: {
    fontSize: 12,
    fontFamily: "NotoSansTC_400Regular",
    marginTop: 4,
  },
  username: {
    fontSize: 24,
    fontFamily: "NotoSansTC_700Bold",
    marginTop: 4,
  },
  joinDate: {
    fontSize: 13,
    fontFamily: "NotoSansTC_400Regular",
  },
  statsRow: {
    flexDirection: "row",
    gap: 12,
  },
  statBox: {
    flex: 1,
    borderRadius: 18,
    padding: 16,
    alignItems: "center",
    gap: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  statNumber: {
    fontSize: 20,
    fontFamily: "NotoSansTC_700Bold",
  },
  statText: {
    fontSize: 12,
    fontFamily: "NotoSansTC_400Regular",
  },
  menuCard: {
    borderRadius: 24,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 16,
    elevation: 3,
  },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 14,
  },
  menuIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  menuLabel: {
    fontSize: 16,
    fontFamily: "NotoSansTC_500Medium",
    flex: 1,
  },
  menuRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  menuValue: {
    fontSize: 13,
    fontFamily: "NotoSansTC_400Regular",
  },
  menuDivider: {
    height: 1,
    marginLeft: 70,
  },
  supportGroup: {
    gap: 10,
  },
  supportRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
  },
  supportRowText: {
    fontSize: 14,
    fontFamily: "NotoSansTC_500Medium",
    flex: 1,
  },
  footerSection: {
    alignItems: "center",
    gap: 4,
    paddingVertical: 20,
  },
  footerText: {
    fontSize: 14,
    fontFamily: "NotoSansTC_500Medium",
  },
  footerVersion: {
    fontSize: 12,
    fontFamily: "NotoSansTC_400Regular",
  },
});
