import { QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect, useState } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { queryClient } from "@/lib/query-client";
import { AppProvider, useApp } from "@/lib/AppContext";
import { ThemeProvider, useThemeColors } from "@/lib/ThemeContext";
import WelcomeModal from "@/components/WelcomeModal";
import { useFonts, NotoSansTC_400Regular, NotoSansTC_500Medium, NotoSansTC_700Bold } from "@expo-google-fonts/noto-sans-tc";

SplashScreen.preventAutoHideAsync();

function WelcomeOverlay() {
  const { user } = useApp();
  const [showWelcome, setShowWelcome] = useState(false);

  useEffect(() => {
    if (user) {
      const timer = setTimeout(() => setShowWelcome(true), 500);
      return () => clearTimeout(timer);
    }
  }, [user?.username]);

  if (!user) return null;

  return (
    <WelcomeModal
      visible={showWelcome}
      onClose={() => setShowWelcome(false)}
      username={user.username}
    />
  );
}

function RootLayoutNav() {
  const colors = useThemeColors();

  return (
    <>
      <Stack
        screenOptions={{
          headerBackTitle: "Back",
          contentStyle: { backgroundColor: colors.background },
        }}
      >
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="login" options={{ headerShown: false }} />
        <Stack.Screen name="birthday" options={{ headerShown: false, presentation: "modal" }} />
      </Stack>
      <WelcomeOverlay />
    </>
  );
}

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    NotoSansTC_400Regular,
    NotoSansTC_500Medium,
    NotoSansTC_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) return null;

  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <GestureHandlerRootView>
          <KeyboardProvider>
            <ThemeProvider>
              <AppProvider>
                <RootLayoutNav />
              </AppProvider>
            </ThemeProvider>
          </KeyboardProvider>
        </GestureHandlerRootView>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}
