interface Quote {
  zh: string;
  en: string;
  author_zh: string;
  author_en: string;
}

const QUOTES: Quote[] = [
  {
    zh: "生命不在於活得長與短，而在於頓悟的早與晚。",
    en: "Life is not about how long you live, but when you awaken.",
    author_zh: "慧能",
    author_en: "Huineng",
  },
  {
    zh: "每一個不曾起舞的日子，都是對生命的辜負。",
    en: "Every day you don't dance is a day wasted.",
    author_zh: "尼采",
    author_en: "Nietzsche",
  },
  {
    zh: "活在當下，感恩每一天。",
    en: "Live in the present, be grateful for each day.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "最好的時光，是你深深覺得自己正在好好活著的時刻。",
    en: "The best moments are when you truly feel alive.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "人生就像一杯茶，不會苦一輩子，但總會苦一陣子。",
    en: "Life is like tea — it won't be bitter forever, but it may be bitter for a while.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "溫柔地對待自己，你正在做一件很不容易的事——活著。",
    en: "Be gentle with yourself. You're doing something incredibly hard — living.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "不要等到失去了才懂得珍惜，每一天都值得被好好對待。",
    en: "Don't wait until you lose something to appreciate it. Every day deserves care.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "慢慢來，比較快。",
    en: "Slow down — it's actually faster.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "你不必每天都過得精彩，但可以每天都過得真誠。",
    en: "You don't need to be amazing every day — just be authentic.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "世界上最治癒的東西，第一是睡覺，第二是美食，第三是被人理解。",
    en: "The most healing things: sleep, good food, and being understood.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "把每一天都當成一份禮物來打開。",
    en: "Unwrap each day like a gift.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "人生沒有白走的路，每一步都算數。",
    en: "No step in life is wasted — every one counts.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "你現在的狀態，就是你最好的狀態。",
    en: "Where you are right now is exactly where you need to be.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "允許自己脆弱，也是一種勇敢。",
    en: "Allowing yourself to be vulnerable is also an act of courage.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "即使生活再忙碌，也要記得停下來看看天空。",
    en: "No matter how busy life gets, remember to pause and look at the sky.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "你值得被溫柔以待。",
    en: "You deserve to be treated with tenderness.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "生活不是等待暴風雨過去，而是學會在雨中跳舞。",
    en: "Life isn't about waiting for the storm to pass — it's learning to dance in the rain.",
    author_zh: "薇薇安·乾恩",
    author_en: "Vivian Greene",
  },
  {
    zh: "做你自己，因為別人都有人做了。",
    en: "Be yourself; everyone else is already taken.",
    author_zh: "王爾德",
    author_en: "Oscar Wilde",
  },
  {
    zh: "今天的你，比昨天更強大。",
    en: "You are stronger today than you were yesterday.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "深呼吸，一切都會好的。",
    en: "Take a deep breath — everything will be okay.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "幸福不是擁有很多，而是計較很少。",
    en: "Happiness isn't having everything — it's caring about less.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "在最深的絕望裡，遇見最美麗的風景。",
    en: "In the deepest despair, you find the most beautiful scenery.",
    author_zh: "幾米",
    author_en: "Jimmy Liao",
  },
  {
    zh: "所有你失去的，都會以另一種方式歸來。",
    en: "Everything you lose comes back in another form.",
    author_zh: "魯米",
    author_en: "Rumi",
  },
  {
    zh: "花開有時，落有時，一切都有時。",
    en: "There's a time to bloom and a time to fall — there's a time for everything.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "接受不完美的自己，才是真正的完美。",
    en: "Accepting your imperfections is true perfection.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "你來到這個世界，就是為了好好感受。",
    en: "You came into this world to truly feel.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "每一次呼吸，都是一次新的開始。",
    en: "Every breath is a new beginning.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "沒有誰的人生是容易的，但你已經做得很好了。",
    en: "Nobody's life is easy — but you're doing great.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "時間會帶走一切煩惱，你只需要耐心等待。",
    en: "Time heals all worries. Just be patient.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
  {
    zh: "你不孤單，世界上有很多人和你一樣。",
    en: "You're not alone — many others feel the same way.",
    author_zh: "佚名",
    author_en: "Unknown",
  },
];

export function getDailyQuote(): Quote {
  const now = new Date();
  const dayOfYear = Math.floor(
    (now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24)
  );
  const index = dayOfYear % QUOTES.length;
  return QUOTES[index];
}

export type { Quote };
