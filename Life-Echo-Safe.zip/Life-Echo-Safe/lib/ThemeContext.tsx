import React, { createContext, useContext, useMemo } from "react";
import { useColorScheme } from "react-native";
import Colors from "@/constants/colors";

type ThemeMode = "light" | "dark";

interface ThemeContextValue {
  mode: ThemeMode;
  colors: typeof Colors.light;
}

const ThemeContext = createContext<ThemeContextValue>({
  mode: "light",
  colors: Colors.light,
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const systemScheme = useColorScheme();
  const mode: ThemeMode = systemScheme === "dark" ? "dark" : "light";

  const value = useMemo(() => ({
    mode,
    colors: mode === "dark" ? Colors.dark : Colors.light,
  }), [mode]);

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}

export function useThemeColors() {
  return useContext(ThemeContext).colors;
}
