import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode, useCallback } from "react";
import { Platform } from "react-native";
import * as Storage from "@/lib/storage";
import { I18nContext, Language, getSavedLanguage, saveLanguage, translations, TranslationKey } from "@/lib/i18n";
import { setupNotifications, cancelAllReminders } from "@/lib/notifications";

interface AppContextValue {
  user: Storage.UserData | null;
  birthday: string | null;
  checkedInToday: boolean;
  streak: number;
  todayMood: Storage.MoodEntry | null;
  moods: Storage.MoodEntry[];
  todayDiary: Storage.DiaryEntry | null;
  diaries: Storage.DiaryEntry[];
  isLoading: boolean;
  birthdayLocked: boolean;
  avatarUri: string | null;
  login: (username: string) => Promise<void>;
  logout: () => Promise<void>;
  setBirthday: (date: string) => Promise<void>;
  checkIn: () => Promise<void>;
  recordMood: (mood: Storage.MoodType) => Promise<void>;
  saveDiaryText: (text: string) => Promise<void>;
  setAvatar: (uri: string) => Promise<void>;
  refreshData: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<Storage.UserData | null>(null);
  const [birthday, setBirthdayState] = useState<string | null>(null);
  const [checkedInToday, setCheckedInToday] = useState(false);
  const [streak, setStreak] = useState(0);
  const [todayMood, setTodayMood] = useState<Storage.MoodEntry | null>(null);
  const [moods, setMoods] = useState<Storage.MoodEntry[]>([]);
  const [todayDiary, setTodayDiary] = useState<Storage.DiaryEntry | null>(null);
  const [diaries, setDiaries] = useState<Storage.DiaryEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [lang, setLangState] = useState<Language>("zh");
  const [avatarUri, setAvatarUri] = useState<string | null>(null);
  const [birthdayLocked, setBirthdayLockedState] = useState(false);

  const refreshData = useCallback(async () => {
    try {
      const [u, b, checked, s, tm, allMoods, td, allDiaries, savedLang, av, locked] = await Promise.all([
        Storage.getUser(),
        Storage.getBirthday(),
        Storage.hasCheckedInToday(),
        Storage.getStreak(),
        Storage.getTodayMood(),
        Storage.getMoods(),
        Storage.getTodayDiary(),
        Storage.getDiaries(),
        getSavedLanguage(),
        Storage.getAvatar(),
        Storage.isBirthdayLocked(),
      ]);
      setUser(u);
      setBirthdayState(b);
      setCheckedInToday(checked);
      setStreak(s);
      setTodayMood(tm);
      setMoods(allMoods);
      setTodayDiary(td);
      setDiaries(allDiaries);
      setLangState(savedLang);
      setAvatarUri(av);
      setBirthdayLockedState(locked);
    } catch (e) {
      console.error("Failed to load data:", e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  useEffect(() => {
    if (user && !isLoading) {
      setupNotifications(checkedInToday).catch(() => {});
    }
  }, [user, checkedInToday, isLoading]);

  const login = useCallback(async (username: string) => {
    const userData: Storage.UserData = { username, createdAt: new Date().toISOString() };
    await Storage.saveUser(userData);
    setUser(userData);
  }, []);

  const logout = useCallback(async () => {
    await Storage.clearUser();
    setUser(null);
    setBirthdayState(null);
    setCheckedInToday(false);
    setStreak(0);
    setTodayMood(null);
    setMoods([]);
    setTodayDiary(null);
    setDiaries([]);
    setAvatarUri(null);
    setBirthdayLockedState(false);
  }, []);

  const setBirthday = useCallback(async (date: string) => {
    await Storage.saveBirthday(date);
    setBirthdayState(date);
    setBirthdayLockedState(true);
  }, []);

  const checkIn = useCallback(async () => {
    await Storage.addCheckIn();
    setCheckedInToday(true);
    const s = await Storage.getStreak();
    setStreak(s);
    cancelAllReminders().catch(() => {});
  }, []);

  const recordMood = useCallback(async (mood: Storage.MoodType) => {
    const entry = await Storage.addMood(mood);
    setTodayMood(entry);
    const allMoods = await Storage.getMoods();
    setMoods(allMoods);
  }, []);

  const saveDiaryText = useCallback(async (text: string) => {
    const entry = await Storage.saveDiary(text);
    setTodayDiary(entry);
    const allDiaries = await Storage.getDiaries();
    setDiaries(allDiaries);
  }, []);

  const setAvatar = useCallback(async (uri: string) => {
    await Storage.saveAvatar(uri);
    setAvatarUri(uri);
  }, []);

  const t = useCallback((key: TranslationKey): string => {
    return translations[lang][key] || key;
  }, [lang]);

  const toggleLang = useCallback(async () => {
    const newLang = lang === "zh" ? "en" : "zh";
    setLangState(newLang);
    await saveLanguage(newLang);
  }, [lang]);

  const setLang = useCallback(async (newLang: Language) => {
    setLangState(newLang);
    await saveLanguage(newLang);
  }, []);

  const appValue = useMemo(
    () => ({
      user,
      birthday,
      checkedInToday,
      streak,
      todayMood,
      moods,
      todayDiary,
      diaries,
      isLoading,
      birthdayLocked,
      avatarUri,
      login,
      logout,
      setBirthday,
      checkIn,
      recordMood,
      saveDiaryText,
      setAvatar,
      refreshData,
    }),
    [user, birthday, checkedInToday, streak, todayMood, moods, todayDiary, diaries, isLoading, birthdayLocked, avatarUri, login, logout, setBirthday, checkIn, recordMood, saveDiaryText, setAvatar, refreshData]
  );

  const i18nValue = useMemo(() => ({ lang, t, toggleLang, setLang }), [lang, t, toggleLang, setLang]);

  return (
    <I18nContext.Provider value={i18nValue}>
      <AppContext.Provider value={appValue}>{children}</AppContext.Provider>
    </I18nContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}
