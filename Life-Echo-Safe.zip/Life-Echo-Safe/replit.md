# Life Echo (餘生記)

## Overview
A mobile app for solo living individuals featuring life countdown, daily check-ins, mood tracking, diary entries, and daily inspiration quotes. Built with Expo (React Native) + Express backend.

## Architecture
- **Frontend**: Expo Router (file-based routing), React Native, TypeScript
- **Backend**: Express server on port 5000 (serves API + landing page)
- **Frontend Dev Server**: Expo on port 8081
- **State**: React Context (AppContext) + AsyncStorage for persistence
- **Styling**: React Native StyleSheet, warm peach/cream palette with dark mode support
- **Font**: NotoSans TC (Chinese)
- **Theme**: Automatic day/night switching via useColorScheme + ThemeContext

## Key Features
- **Life Countdown**: 80-year baseline, progress ring with percentage + "剩餘 X 年" text in center (no stats row)
- **Live Countdown Timer**: Real-time ticking display with animated scale pulse (TickingDigit component), updated every second
- **Daily Check-in**: Check-in button, streak tracking, haptic feedback. "本人又成功活了 X 天" appears as CheckInToast modal popup only after checking in (auto-dismisses after 3s)
- **Mood Tracking**: 5 moods (happy, normal, down, anxious, tired), 7-day trend chart
- **Mood Calendar**: Monthly calendar modal showing mood icons per day, month navigation
- **Marquee Banner**: Animated scrolling text on ALL tabs "{username} 你很棒，超級棒，要努力活著喔" with separator "✧"
- **Floating Motivational Texts**: 8 animated phrases ("你竟然還活著！", "你好棒", "今天你做到了" etc.) that float and flicker across all 4 tabs with varied timing, drift, and opacity
- **Solo Living Challenges (4th tab)**: 30 curated challenges across 5 categories (self, explore, create, connect, mindful), dynamically selected (8-24) based on remaining weekends count, with monthly seed for consistency
- **Text Diary**: Title "今日心裡話" with explicit save/record button (icon + "記錄" text)
- **Daily Inspiration**: 30 curated bilingual quotes rotating by day of year
- **Social Sharing**: Share button on home screen sharing remaining weekends, today's mood, and brand slogan via native Share API
- **Avatar Upload**: Profile photo upload via expo-image-picker with camera badge overlay, prompt text "上傳一張你最喜歡的自己"
- **Developer Support**: Compact row button "支持開發者" opening SupportModal with developer story and donation info
- **Upcoming Features Modal**: "繼續優化中" button in profile opens UpcomingFeaturesModal showing 6 blurred upcoming features (tarot quotes, unlimited future letters, full diary, AI mood analysis, future letter, emergency alerts) with BlurView on iOS
- **Welcome Modal**: Frosted glass modal "嗨，幸好你還活著！！" appears 500ms after login with BlurView + animated entrance
- **Push Notifications**: Hourly reminders "你還活著嗎？" from 9am-10pm when user hasn't checked in, cancelled after check-in
- **Day/Night Theme**: Automatic theme switching based on system color scheme preference
- **Gradient Backgrounds**: LinearGradient backgrounds on all screens (home, mood, challenges, profile, login, birthday)
- **i18n**: Chinese/English toggle, stored in AsyncStorage
- **Birthday Lock**: Editable only within 24 hours of registration

## Project Structure
- `app/` - Expo Router screens
  - `(tabs)/index.tsx` - Home (countdown ring, remaining years, live timer, quote, check-in with toast, floating texts)
  - `(tabs)/mood.tsx` - Mood selection + diary + trend chart + calendar + floating texts
  - `(tabs)/challenges.tsx` - Solo living challenge list (30 challenges, 5 categories, weekend-based selection)
  - `(tabs)/profile.tsx` - Profile, language toggle, logout, support, upcoming features + floating texts
  - `(tabs)/_layout.tsx` - 4-tab layout with NativeTabs/BlurView fallback
  - `birthday.tsx` - Birthday setup (modal, with lock state)
  - `login.tsx` - Login screen with gradient
  - `_layout.tsx` - Root layout with providers + WelcomeOverlay
- `lib/`
  - `AppContext.tsx` - Main state provider (includes i18n context + notification integration)
  - `ThemeContext.tsx` - Theme provider with useColorScheme, exports useTheme/useThemeColors
  - `i18n.ts` - Translations, I18nContext, language persistence
  - `quotes.ts` - 30 bilingual daily quotes
  - `storage.ts` - AsyncStorage CRUD (user, birthday, checkins, moods, diaries, avatar)
  - `life-calculator.ts` - Life stats including remainingWeekends
  - `notifications.ts` - expo-notifications setup: hourly reminders, permission handling
- `components/`
  - `MarqueeBanner.tsx` - Animated scrolling marquee text component
  - `FloatingTexts.tsx` - Ambient floating motivational text animations with drift and flicker
  - `UpcomingFeaturesModal.tsx` - "繼續優化中" modal with 6 blurred upcoming features
  - `WelcomeModal.tsx` - Frosted glass welcome modal with blur effect
  - `SupportModal.tsx` - Developer support popup with donation info
  - `ErrorBoundary.tsx` - Error boundary wrapper
- `constants/colors.ts` - Light + dark color palettes with gradient definitions

## Design
- Warm, healing aesthetic inspired by Calm & Apple Health
- Light palette: cream (#FFF8F0), coral (#E8916E), sage (#A8C5A0), gold (#D4A574)
- Dark palette: deep brown (#1A1614), dark cards (#252220), muted borders (#3D3028)
- Gradient backgrounds on all screens
- Cards with subtle shadows, rounded corners (20-24px)
- NotoSansTC font family for Chinese text support
- Frosted glass effects on modals (BlurView on iOS, fallback overlay on web)

## Recent Changes (2026-02-10)
- Tappable trend chart dots: mood chart dots now show diary entry tooltip popup when tapped, with close button
- Coffee button caring prompt: shows Alert "不請沒關係，你好好活著就好" when donation button is clicked
- Birthday permanent lock: birthday can only be set once (no longer 24-hour editable window), stored permanently in AsyncStorage
- Redesigned challenges tab: added task categories (daily/weekly/monthly/personal) with filter tabs, AsyncStorage persistence for completion tracking, personal task creation/deletion
- Added feedback button in SupportModal linking to Google Forms
- AppContext now exposes `diaries` array for trend chart diary lookup

## Previous Changes (2026-02-09)
- Added FloatingLeaves component on login page: 8 animated leaf icons drifting with rotation + 4 flickering sparkle symbols
- Updated logo from single leaf to notebook+leaf combo (MaterialCommunityIcons "notebook-outline" + Ionicons "leaf") on login page and profile footer
- Generated new app icon/splash/favicon assets featuring notebook+leaf design

## Previous Changes (2026-02-08)
- Added FloatingTexts component with 8 animated phrases that float and flicker across all tabs
- Redesigned home screen: removed stats row, added "剩餘 X 年" under progress percentage in ring center
- Moved "本人又成功活了 X 天" banner to CheckInToast modal that appears only after user checks in (auto-dismiss 3s)
- Added 4th tab "獨處挑戰清單" with 30 challenges across 5 categories, dynamically selected based on remaining weekends
- Added UpcomingFeaturesModal ("繼續優化中") in profile with 6 blurred upcoming features
- Updated tab layout from 3 to 4 tabs
- Added automatic day/night theme switching (ThemeContext with useColorScheme)
- Added MarqueeBanner component shown on all four tabs
- Added WelcomeModal with frosted glass blur effect on app open
- Changed diary title to "今日心裡話" with explicit save button
- Added TickingDigit component with scale pulse animation for countdown timer
- Added expo-notifications for hourly check-in reminders
- Redesigned developer support as compact row + SupportModal popup
- Applied LinearGradient backgrounds to all screens
- Updated all screens to use theme-aware colors (dark mode support)
