import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, Modal, Pressable, Platform } from "react-native";
import { BlurView } from "expo-blur";
import { Ionicons } from "@expo/vector-icons";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withDelay,
  withSpring,
} from "react-native-reanimated";
import * as Haptics from "expo-haptics";
import { useTheme } from "@/lib/ThemeContext";

interface WelcomeModalProps {
  visible: boolean;
  onClose: () => void;
  username: string;
}

export default function WelcomeModal({ visible, onClose, username }: WelcomeModalProps) {
  const { mode, colors } = useTheme();
  const scale = useSharedValue(0.8);
  const opacity = useSharedValue(0);
  const iconScale = useSharedValue(0);

  useEffect(() => {
    if (visible) {
      scale.value = withSpring(1, { damping: 15, stiffness: 150 });
      opacity.value = withTiming(1, { duration: 400 });
      iconScale.value = withDelay(200, withSpring(1, { damping: 12 }));
      if (Platform.OS !== "web") {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }
    } else {
      scale.value = 0.8;
      opacity.value = 0;
      iconScale.value = 0;
    }
  }, [visible]);

  const containerAnim = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: opacity.value,
  }));

  const iconAnim = useAnimatedStyle(() => ({
    transform: [{ scale: iconScale.value }],
  }));

  const handleClose = async () => {
    opacity.value = withTiming(0, { duration: 200 });
    scale.value = withTiming(0.8, { duration: 200 });
    setTimeout(onClose, 220);
  };

  const isWeb = Platform.OS === "web";

  return (
    <Modal visible={visible} transparent animationType="none">
      <View style={styles.overlay}>
        {!isWeb ? (
          <BlurView
            intensity={40}
            tint={mode === "dark" ? "dark" : "light"}
            style={StyleSheet.absoluteFill}
          />
        ) : (
          <View style={[StyleSheet.absoluteFill, styles.webBlur]} />
        )}
        <Animated.View style={[styles.card, { backgroundColor: colors.cardBg + "F0" }, containerAnim]}>
          <Animated.View style={iconAnim}>
            <View style={[styles.iconCircle, { backgroundColor: "rgba(168, 197, 160, 0.15)" }]}>
              <Ionicons name="leaf" size={36} color={colors.sage} />
            </View>
          </Animated.View>

          <Text style={[styles.greeting, { color: colors.textPrimary }]}>
            {username ? `${username}` : ""}
          </Text>
          <Text style={[styles.mainText, { color: colors.coral }]}>
            嗨，幸好你還活著！！
          </Text>
          <Text style={[styles.subText, { color: colors.textSecondary }]}>
            今天也要好好的喔
          </Text>

          <Pressable
            onPress={handleClose}
            style={({ pressed }) => [
              styles.closeBtn,
              { backgroundColor: colors.coral },
              pressed && { opacity: 0.85, transform: [{ scale: 0.97 }] },
            ]}
          >
            <Ionicons name="heart" size={18} color="#FFF" />
          </Pressable>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 40,
  },
  webBlur: {
    backgroundColor: "rgba(0,0,0,0.3)",
  },
  card: {
    borderRadius: 28,
    paddingVertical: 36,
    paddingHorizontal: 32,
    alignItems: "center",
    gap: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 24,
    elevation: 8,
    width: "100%",
    maxWidth: 320,
  },
  iconCircle: {
    width: 68,
    height: 68,
    borderRadius: 34,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  greeting: {
    fontSize: 16,
    fontFamily: "NotoSansTC_500Medium",
  },
  mainText: {
    fontSize: 22,
    fontFamily: "NotoSansTC_700Bold",
    textAlign: "center",
    letterSpacing: 1,
  },
  subText: {
    fontSize: 14,
    fontFamily: "NotoSansTC_400Regular",
    marginTop: 2,
  },
  closeBtn: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 12,
  },
});
