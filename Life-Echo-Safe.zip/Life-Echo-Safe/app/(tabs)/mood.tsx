import React, { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  Platform,
  ScrollView,
  TextInput,
  Modal,
  Dimensions,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSpring,
} from "react-native-reanimated";
import Svg, { Circle as SvgCircle, Line, G } from "react-native-svg";
import { LinearGradient } from "expo-linear-gradient";
import { useThemeColors } from "@/lib/ThemeContext";
import { useApp } from "@/lib/AppContext";
import { useI18n } from "@/lib/i18n";
import { getRecentMoods, getMoodForDate, type MoodType, type MoodEntry, type DiaryEntry } from "@/lib/storage";
import MarqueeBanner from "@/components/MarqueeBanner";
import FloatingTexts from "@/components/FloatingTexts";

interface MoodOption {
  type: MoodType;
  icon: keyof typeof Ionicons.glyphMap;
  labelKey: "moodHappy" | "moodNormal" | "moodDown" | "moodAnxious" | "moodTired";
  color: string;
  bgColor: string;
}

const MOOD_OPTIONS: MoodOption[] = [
  { type: "happy", icon: "happy-outline", labelKey: "moodHappy", color: "#F2A04A", bgColor: "rgba(242, 160, 74, 0.12)" },
  { type: "normal", icon: "ellipse-outline", labelKey: "moodNormal", color: "#8DBAD4", bgColor: "rgba(141, 186, 212, 0.12)" },
  { type: "down", icon: "rainy-outline", labelKey: "moodDown", color: "#A094C7", bgColor: "rgba(160, 148, 199, 0.12)" },
  { type: "anxious", icon: "thunderstorm-outline", labelKey: "moodAnxious", color: "#E8916E", bgColor: "rgba(232, 145, 110, 0.12)" },
  { type: "tired", icon: "moon-outline", labelKey: "moodTired", color: "#A8C5A0", bgColor: "rgba(168, 197, 160, 0.12)" },
];

const MOOD_VALUES: Record<MoodType, number> = {
  happy: 5,
  normal: 4,
  down: 2,
  anxious: 1,
  tired: 3,
};

function MoodButton({ option, isSelected, onPress, label }: { option: MoodOption; isSelected: boolean; onPress: () => void; label: string }) {
  const scale = useSharedValue(1);
  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <Animated.View style={animStyle}>
      <Pressable
        onPress={() => {
          scale.value = withSpring(0.9, {}, () => {
            scale.value = withSpring(1);
          });
          onPress();
        }}
        style={[
          styles.moodButton,
          { backgroundColor: option.bgColor },
          isSelected && { borderWidth: 2.5, borderColor: option.color },
        ]}
      >
        <Ionicons name={option.icon} size={28} color={option.color} />
        <Text style={[styles.moodLabel, { color: option.color }]}>{label}</Text>
        {isSelected && (
          <View style={[styles.moodCheckmark, { backgroundColor: option.color }]}>
            <Ionicons name="checkmark" size={10} color="#FFF" />
          </View>
        )}
      </Pressable>
    </Animated.View>
  );
}

function MoodChart({ moods, colors, diaries, onDotPress }: { moods: ReturnType<typeof getRecentMoods>; colors: any; diaries: DiaryEntry[]; onDotPress: (date: string, diary: DiaryEntry | null) => void }) {
  const chartW = 300;
  const chartH = 140;
  const paddingLeft = 30;
  const paddingBottom = 24;
  const paddingTop = 16;
  const usableW = chartW - paddingLeft - 10;
  const usableH = chartH - paddingTop - paddingBottom;

  const last7: { date: string; dayLabel: string; value: number | null; mood: MoodType | null }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split("T")[0];
    const entry = moods.find((m) => m.date === dateStr);
    last7.push({
      date: dateStr,
      dayLabel: `${d.getMonth() + 1}/${d.getDate()}`,
      value: entry ? MOOD_VALUES[entry.mood] : null,
      mood: entry?.mood || null,
    });
  }

  const getMoodColor = (mood: MoodType | null) => {
    const opt = MOOD_OPTIONS.find((m) => m.type === mood);
    return opt?.color || colors.textMuted;
  };

  return (
    <View style={styles.chartContainer}>
      <View style={{ width: chartW, height: chartH }}>
        <Svg width={chartW} height={chartH}>
          {[1, 2, 3, 4, 5].map((v) => {
            const y = paddingTop + usableH - ((v - 1) / 4) * usableH;
            return (
              <G key={v}>
                <Line
                  x1={paddingLeft}
                  y1={y}
                  x2={chartW - 10}
                  y2={y}
                  stroke={colors.border}
                  strokeWidth={1}
                  strokeDasharray="4,4"
                />
              </G>
            );
          })}
          {last7.map((item, i) => {
            if (item.value === null) return null;
            const x = paddingLeft + (i / 6) * usableW;
            const y = paddingTop + usableH - ((item.value - 1) / 4) * usableH;
            const prevItem = i > 0 ? last7[i - 1] : null;
            return (
              <G key={item.date}>
                {prevItem?.value !== null && prevItem?.value !== undefined && i > 0 && (
                  <Line
                    x1={paddingLeft + ((i - 1) / 6) * usableW}
                    y1={paddingTop + usableH - ((prevItem.value - 1) / 4) * usableH}
                    x2={x}
                    y2={y}
                    stroke={colors.coralSoft}
                    strokeWidth={2}
                    strokeLinecap="round"
                  />
                )}
                <SvgCircle cx={x} cy={y} r={5} fill={getMoodColor(item.mood)} />
                <SvgCircle cx={x} cy={y} r={8} fill={getMoodColor(item.mood)} opacity={0.15} />
              </G>
            );
          })}
        </Svg>
        {last7.map((item, i) => {
          if (item.value === null) return null;
          const x = paddingLeft + (i / 6) * usableW;
          const y = paddingTop + usableH - ((item.value - 1) / 4) * usableH;
          const diary = diaries.find((d) => d.date === item.date) || null;
          return (
            <Pressable
              key={`dot-${item.date}`}
              onPress={() => onDotPress(item.date, diary)}
              style={{
                position: "absolute",
                left: x - 14,
                top: y - 14,
                width: 28,
                height: 28,
                borderRadius: 14,
              }}
              hitSlop={4}
            />
          );
        })}
      </View>
      <View style={[styles.chartLabels, { paddingLeft, width: chartW - 10 }]}>
        {last7.map((item) => (
          <Text key={item.date} style={[styles.chartDateLabel, { color: colors.textMuted }]}>
            {item.dayLabel}
          </Text>
        ))}
      </View>
    </View>
  );
}

function MoodCalendar({ moods, onClose, colors }: { moods: MoodEntry[]; onClose: () => void; colors: any }) {
  const { t } = useI18n();
  const insets = useSafeAreaInsets();
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const getMoodColor = (mood: MoodType) => {
    const opt = MOOD_OPTIONS.find((m) => m.type === mood);
    return opt?.color || colors.textMuted;
  };

  const getMoodIcon = (mood: MoodType): keyof typeof Ionicons.glyphMap => {
    const opt = MOOD_OPTIONS.find((m) => m.type === mood);
    return opt?.icon || "ellipse-outline";
  };

  const prevMonth = () => setCurrentMonth(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentMonth(new Date(year, month + 1, 1));

  const monthName = currentMonth.toLocaleDateString("zh-TW", { year: "numeric", month: "long" });

  const cells: (number | null)[] = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const weekLabels = ["\u65E5", "\u4E00", "\u4E8C", "\u4E09", "\u56DB", "\u4E94", "\u516D"];

  return (
    <Modal visible animationType="slide" transparent>
      <View style={[styles.calendarOverlay, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 20 }]}>
        <View style={[styles.calendarModal, { backgroundColor: colors.cardBg }]}>
          <View style={styles.calendarHeader}>
            <Text style={[styles.calendarTitle, { color: colors.textPrimary }]}>{t("monthlyCalendar")}</Text>
            <Pressable onPress={onClose} hitSlop={12}>
              <Ionicons name="close" size={24} color={colors.textPrimary} />
            </Pressable>
          </View>

          <View style={styles.calendarNav}>
            <Pressable onPress={prevMonth} hitSlop={12}>
              <Ionicons name="chevron-back" size={22} color={colors.coral} />
            </Pressable>
            <Text style={[styles.calendarMonthLabel, { color: colors.textPrimary }]}>{monthName}</Text>
            <Pressable onPress={nextMonth} hitSlop={12}>
              <Ionicons name="chevron-forward" size={22} color={colors.coral} />
            </Pressable>
          </View>

          <View style={styles.calendarWeekRow}>
            {weekLabels.map((w) => (
              <Text key={w} style={[styles.calendarWeekLabel, { color: colors.textMuted }]}>{w}</Text>
            ))}
          </View>

          <View style={styles.calendarGrid}>
            {cells.map((day, i) => {
              if (day === null) {
                return <View key={`empty-${i}`} style={styles.calendarCell} />;
              }
              const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
              const moodEntry = getMoodForDate(moods, dateStr);
              const isToday = dateStr === new Date().toISOString().split("T")[0];
              return (
                <View key={dateStr} style={[styles.calendarCell, isToday && { backgroundColor: colors.peachLight + "40", borderRadius: 8 }]}>
                  <Text style={[styles.calendarDay, { color: colors.textSecondary }, isToday && { color: colors.coral, fontFamily: "NotoSansTC_700Bold" as const }]}>{day}</Text>
                  {moodEntry ? (
                    <Ionicons name={getMoodIcon(moodEntry.mood)} size={14} color={getMoodColor(moodEntry.mood)} />
                  ) : (
                    <View style={{ height: 14 }} />
                  )}
                </View>
              );
            })}
          </View>

          <View style={styles.calendarLegend}>
            {MOOD_OPTIONS.map((opt) => (
              <View key={opt.type} style={styles.legendItemCal}>
                <Ionicons name={opt.icon} size={12} color={opt.color} />
              </View>
            ))}
          </View>
        </View>
      </View>
    </Modal>
  );
}

export default function MoodScreen() {
  const insets = useSafeAreaInsets();
  const colors = useThemeColors();
  const { user, todayMood, moods, recordMood, todayDiary, saveDiaryText, diaries } = useApp();
  const { t, lang } = useI18n();
  const webTopInset = Platform.OS === "web" ? 67 : 0;
  const [diaryText, setDiaryText] = useState(todayDiary?.text || "");
  const [diarySaved, setDiarySaved] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [selectedDiary, setSelectedDiary] = useState<{ date: string; diary: DiaryEntry | null } | null>(null);

  useEffect(() => {
    if (todayDiary?.text !== undefined && todayDiary?.text !== null) {
      setDiaryText(todayDiary.text);
    }
  }, [todayDiary?.text]);

  const fadeIn = useSharedValue(0);
  useEffect(() => {
    if (!user) {
      router.replace("/login");
      return;
    }
    fadeIn.value = withTiming(1, { duration: 600 });
  }, [user]);

  const containerAnim = useAnimatedStyle(() => ({ opacity: fadeIn.value }));

  const recentMoods = getRecentMoods(moods, 7);

  const handleMoodPress = async (mood: MoodType) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await recordMood(mood);
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleSaveDiary = async () => {
    if (!diaryText.trim()) return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await saveDiaryText(diaryText.trim());
    setDiarySaved(true);
    setTimeout(() => setDiarySaved(false), 2000);
  };

  if (!user) return null;

  const marqueeContent = `${user.username} ${t("marqueeText")}`;

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientMid, colors.gradientEnd]}
      style={styles.screen}
      start={{ x: 0, y: 0 }}
      end={{ x: 0.5, y: 1 }}
    >
      <FloatingTexts />
      <ScrollView
        style={styles.screen}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: insets.top + webTopInset + 8,
            paddingBottom: insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <MarqueeBanner text={marqueeContent} />

        <Animated.View style={[styles.container, containerAnim]}>
          <Text style={[styles.pageTitle, { color: colors.textPrimary }]}>{t("moodRecord")}</Text>
          <Text style={[styles.pageSubtitle, { color: colors.textSecondary }]}>
            {t("recordMoodToday")}
          </Text>

          <View style={[styles.moodCard, { backgroundColor: colors.cardBg }]}>
            <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>
              {todayMood ? t("todaysMood") : t("howDoYouFeel")}
            </Text>
            <View style={styles.moodGrid}>
              {MOOD_OPTIONS.map((option) => (
                <MoodButton
                  key={option.type}
                  option={option}
                  isSelected={todayMood?.mood === option.type}
                  onPress={() => handleMoodPress(option.type)}
                  label={t(option.labelKey)}
                />
              ))}
            </View>
            {todayMood && (
              <Text style={[styles.moodNote, { color: colors.textMuted }]}>
                {t("canUpdateMood")}
              </Text>
            )}
          </View>

          <View style={[styles.diaryCard, { backgroundColor: colors.cardBg }]}>
            <View style={styles.diaryHeader}>
              <View style={styles.diaryTitleRow}>
                <Ionicons name="chatbubble-ellipses-outline" size={18} color={colors.coral} />
                <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>{t("diaryTitle")}</Text>
              </View>
              {diarySaved && (
                <View style={styles.savedBadge}>
                  <Ionicons name="checkmark-circle" size={14} color={colors.sage} />
                  <Text style={[styles.savedText, { color: colors.sage }]}>{t("saved")}</Text>
                </View>
              )}
            </View>
            <Text style={[styles.diaryHint, { color: colors.textMuted }]}>{t("diaryHint")}</Text>
            <TextInput
              style={[styles.diaryInput, {
                backgroundColor: colors.background + "80",
                borderColor: colors.border,
                color: colors.textPrimary,
              }]}
              placeholder={t("diaryPlaceholder")}
              placeholderTextColor={colors.textMuted}
              value={diaryText}
              onChangeText={setDiaryText}
              multiline
              textAlignVertical="top"
              maxLength={500}
            />
            <Pressable
              onPress={handleSaveDiary}
              disabled={!diaryText.trim()}
              style={({ pressed }) => [
                styles.saveBtn,
                { backgroundColor: diaryText.trim() ? colors.coral : colors.border },
                pressed && diaryText.trim() && { opacity: 0.85, transform: [{ scale: 0.97 }] },
              ]}
            >
              <Ionicons name="bookmark-outline" size={16} color={diaryText.trim() ? "#FFF" : colors.textMuted} />
              <Text style={[styles.saveBtnText, { color: diaryText.trim() ? "#FFF" : colors.textMuted }]}>
                {t("saveButton")}
              </Text>
            </Pressable>
          </View>

          <View style={[styles.trendCard, { backgroundColor: colors.cardBg }]}>
            <View style={styles.trendHeader}>
              <Text style={[styles.cardTitle, { color: colors.textPrimary }]}>{t("last7DaysTrend")}</Text>
              <Pressable
                onPress={() => setShowCalendar(true)}
                style={({ pressed }) => [
                  styles.calendarBtn,
                  pressed && { opacity: 0.7 },
                ]}
                hitSlop={8}
              >
                <Ionicons name="calendar-outline" size={18} color={colors.coral} />
              </Pressable>
            </View>
            {recentMoods.length === 0 ? (
              <View style={styles.emptyChart}>
                <Ionicons name="analytics-outline" size={36} color={colors.textMuted} />
                <Text style={[styles.emptyChartText, { color: colors.textMuted }]}>
                  {t("startRecordingMood")}
                </Text>
              </View>
            ) : (
              <>
                <MoodChart
                  moods={recentMoods}
                  colors={colors}
                  diaries={diaries}
                  onDotPress={(date, diary) => setSelectedDiary({ date, diary })}
                />
                {selectedDiary && (
                  <View style={[styles.tooltipCard, { backgroundColor: colors.cardBg, borderColor: colors.border }]}>
                    <View style={styles.tooltipHeader}>
                      <Text style={[styles.tooltipDate, { color: colors.coral }]}>{selectedDiary.date}</Text>
                      <Pressable onPress={() => setSelectedDiary(null)} hitSlop={8}>
                        <Ionicons name="close-circle" size={20} color={colors.textMuted} />
                      </Pressable>
                    </View>
                    <Text style={[styles.tooltipText, { color: colors.textPrimary }]} numberOfLines={4}>
                      {selectedDiary.diary
                        ? selectedDiary.diary.text
                        : (lang === "zh" ? "當天沒有日記紀錄" : "No diary entry for this day")}
                    </Text>
                  </View>
                )}
              </>
            )}

            <View style={styles.legendRow}>
              {MOOD_OPTIONS.map((opt) => (
                <View key={opt.type} style={styles.legendItem}>
                  <View style={[styles.legendDot, { backgroundColor: opt.color }]} />
                  <Text style={[styles.legendLabel, { color: colors.textSecondary }]}>{t(opt.labelKey)}</Text>
                </View>
              ))}
            </View>
          </View>
        </Animated.View>

        {showCalendar && (
          <MoodCalendar moods={moods} onClose={() => setShowCalendar(false)} colors={colors} />
        )}
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  scrollContent: { flexGrow: 1 },
  container: {
    paddingHorizontal: 20,
    gap: 20,
    paddingTop: 12,
  },
  pageTitle: {
    fontSize: 26,
    fontFamily: "NotoSansTC_700Bold",
  },
  pageSubtitle: {
    fontSize: 15,
    fontFamily: "NotoSansTC_400Regular",
    marginTop: -12,
  },
  moodCard: {
    borderRadius: 24,
    padding: 24,
    gap: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 16,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 17,
    fontFamily: "NotoSansTC_700Bold",
  },
  moodGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    justifyContent: "center",
  },
  moodButton: {
    width: 80,
    height: 84,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    borderWidth: 1.5,
    borderColor: "transparent",
  },
  moodLabel: {
    fontSize: 13,
    fontFamily: "NotoSansTC_500Medium",
  },
  moodCheckmark: {
    position: "absolute",
    top: 4,
    right: 4,
    width: 18,
    height: 18,
    borderRadius: 9,
    alignItems: "center",
    justifyContent: "center",
  },
  moodNote: {
    fontSize: 12,
    fontFamily: "NotoSansTC_400Regular",
    textAlign: "center",
  },
  diaryCard: {
    borderRadius: 24,
    padding: 24,
    gap: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 16,
    elevation: 3,
  },
  diaryHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  diaryTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  savedBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: "rgba(168, 197, 160, 0.15)",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  savedText: {
    fontSize: 12,
    fontFamily: "NotoSansTC_500Medium",
  },
  diaryHint: {
    fontSize: 13,
    fontFamily: "NotoSansTC_400Regular",
  },
  diaryInput: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    fontSize: 15,
    fontFamily: "NotoSansTC_400Regular",
    minHeight: 120,
    lineHeight: 24,
  },
  saveBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 12,
    borderRadius: 14,
    alignSelf: "flex-end",
    paddingHorizontal: 24,
  },
  saveBtnText: {
    fontSize: 14,
    fontFamily: "NotoSansTC_700Bold",
  },
  trendCard: {
    borderRadius: 24,
    padding: 24,
    gap: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 16,
    elevation: 3,
  },
  trendHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  calendarBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "rgba(232, 145, 110, 0.1)",
    alignItems: "center",
    justifyContent: "center",
  },
  chartContainer: {
    alignItems: "center",
  },
  chartLabels: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 4,
  },
  chartDateLabel: {
    fontSize: 10,
    fontFamily: "NotoSansTC_400Regular",
  },
  emptyChart: {
    alignItems: "center",
    gap: 8,
    paddingVertical: 24,
  },
  emptyChartText: {
    fontSize: 13,
    fontFamily: "NotoSansTC_400Regular",
    textAlign: "center",
  },
  legendRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
    justifyContent: "center",
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  legendLabel: {
    fontSize: 11,
    fontFamily: "NotoSansTC_400Regular",
  },
  calendarOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "center",
    paddingHorizontal: 16,
  },
  calendarModal: {
    borderRadius: 24,
    padding: 24,
    gap: 16,
    maxHeight: "85%",
  },
  calendarHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  calendarTitle: {
    fontSize: 18,
    fontFamily: "NotoSansTC_700Bold",
  },
  calendarNav: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 8,
  },
  calendarMonthLabel: {
    fontSize: 16,
    fontFamily: "NotoSansTC_500Medium",
  },
  calendarWeekRow: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  calendarWeekLabel: {
    width: 40,
    textAlign: "center",
    fontSize: 12,
    fontFamily: "NotoSansTC_500Medium",
  },
  calendarGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  calendarCell: {
    width: `${100 / 7}%`,
    aspectRatio: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 2,
  },
  calendarDay: {
    fontSize: 13,
    fontFamily: "NotoSansTC_400Regular",
  },
  calendarLegend: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 16,
  },
  legendItemCal: {
    alignItems: "center",
    justifyContent: "center",
  },
  tooltipCard: {
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    gap: 6,
    marginTop: 8,
  },
  tooltipHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  tooltipDate: {
    fontSize: 13,
    fontFamily: "NotoSansTC_700Bold",
  },
  tooltipText: {
    fontSize: 13,
    fontFamily: "NotoSansTC_400Regular",
    lineHeight: 20,
  },
});
