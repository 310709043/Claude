import React, { useEffect } from "react";
import { View, Text, StyleSheet, Dimensions } from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  Easing,
} from "react-native-reanimated";
import { Ionicons } from "@expo/vector-icons";
import { useThemeColors } from "@/lib/ThemeContext";

interface MarqueeBannerProps {
  text: string;
}

export default function MarqueeBanner({ text }: MarqueeBannerProps) {
  const colors = useThemeColors();
  const screenWidth = Dimensions.get("window").width;
  const separator = "    \u2727    ";
  const fullText = `${text}${separator}${text}${separator}${text}${separator}`;
  const translateX = useSharedValue(0);

  useEffect(() => {
    translateX.value = 0;
    translateX.value = withRepeat(
      withTiming(-screenWidth * 1.5, { duration: 18000, easing: Easing.linear }),
      -1,
      false
    );
  }, [text]);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateX.value }],
  }));

  return (
    <View style={[styles.container, { backgroundColor: colors.marqueeGradientStart }]}>
      <Animated.View style={[styles.inner, animStyle]}>
        <Text style={[styles.text, { color: colors.coral }]} numberOfLines={1}>
          {fullText}
        </Text>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 32,
    overflow: "hidden",
    justifyContent: "center",
    borderRadius: 8,
    marginHorizontal: 16,
    marginBottom: 8,
  },
  inner: {
    flexDirection: "row",
    position: "absolute",
    width: 3000,
    paddingHorizontal: 8,
  },
  text: {
    fontSize: 13,
    fontFamily: "NotoSansTC_500Medium",
    letterSpacing: 2,
  },
});
