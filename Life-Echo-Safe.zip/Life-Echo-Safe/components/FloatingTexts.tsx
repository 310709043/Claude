import React, { useEffect, useMemo } from "react";
import { StyleSheet, Dimensions } from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
  withDelay,
  Easing,
} from "react-native-reanimated";
import { useThemeColors } from "@/lib/ThemeContext";
import { useI18n } from "@/lib/i18n";

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get("window");

const TEXTS_ZH = [
  "你竟然還活著！",
  "你好棒",
  "今天你做到了",
  "繼續加油",
  "活著就是奇蹟",
  "你值得被愛",
  "今天也辛苦了",
  "好好呼吸",
];

const TEXTS_EN = [
  "You're still alive!",
  "You're amazing",
  "You did it today",
  "Keep going",
  "Living is a miracle",
  "You deserve love",
  "Great job today",
  "Breathe deeply",
];

interface FloatConfig {
  textIndex: number;
  startX: number;
  startY: number;
  driftX: number;
  driftY: number;
  duration: number;
  delay: number;
  fontSize: number;
}

function FloatingText({ config, texts }: { config: FloatConfig; texts: string[] }) {
  const colors = useThemeColors();
  const opacity = useSharedValue(0);
  const translateX = useSharedValue(config.startX);
  const translateY = useSharedValue(config.startY);

  useEffect(() => {
    opacity.value = withDelay(
      config.delay,
      withRepeat(
        withSequence(
          withTiming(0.6, { duration: 1200, easing: Easing.out(Easing.ease) }),
          withTiming(0.15, { duration: 1800, easing: Easing.inOut(Easing.ease) }),
          withTiming(0.5, { duration: 1000, easing: Easing.out(Easing.ease) }),
          withTiming(0, { duration: 1500, easing: Easing.in(Easing.ease) }),
          withTiming(0, { duration: 2000 })
        ),
        -1,
        false
      )
    );

    translateX.value = withDelay(
      config.delay,
      withRepeat(
        withSequence(
          withTiming(config.startX + config.driftX, { duration: config.duration, easing: Easing.inOut(Easing.ease) }),
          withTiming(config.startX, { duration: config.duration, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        true
      )
    );

    translateY.value = withDelay(
      config.delay,
      withRepeat(
        withSequence(
          withTiming(config.startY + config.driftY, { duration: config.duration * 1.2, easing: Easing.inOut(Easing.ease) }),
          withTiming(config.startY, { duration: config.duration * 1.2, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        true
      )
    );
  }, []);

  const animStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
    ],
  }));

  return (
    <Animated.Text
      style={[
        styles.floatingText,
        {
          fontSize: config.fontSize,
          color: colors.coral,
        },
        animStyle,
      ]}
      pointerEvents="none"
    >
      {texts[config.textIndex % texts.length]}
    </Animated.Text>
  );
}

export default function FloatingTexts() {
  const { lang } = useI18n();
  const texts = lang === "zh" ? TEXTS_ZH : TEXTS_EN;

  const configs: FloatConfig[] = useMemo(() => [
    { textIndex: 0, startX: 20, startY: 80, driftX: 30, driftY: -20, duration: 5000, delay: 0, fontSize: 12 },
    { textIndex: 1, startX: SCREEN_WIDTH - 120, startY: 200, driftX: -25, driftY: 15, duration: 6000, delay: 2000, fontSize: 11 },
    { textIndex: 2, startX: 40, startY: 350, driftX: 20, driftY: -30, duration: 5500, delay: 4000, fontSize: 10 },
    { textIndex: 3, startX: SCREEN_WIDTH - 140, startY: 480, driftX: -15, driftY: 20, duration: 7000, delay: 1500, fontSize: 11 },
    { textIndex: 4, startX: 60, startY: 550, driftX: 25, driftY: -15, duration: 6500, delay: 3500, fontSize: 10 },
    { textIndex: 5, startX: SCREEN_WIDTH - 110, startY: 120, driftX: -20, driftY: -25, duration: 5800, delay: 5000, fontSize: 12 },
  ], []);

  return (
    <>
      {configs.map((config, i) => (
        <FloatingText key={i} config={config} texts={texts} />
      ))}
    </>
  );
}

const styles = StyleSheet.create({
  floatingText: {
    position: "absolute",
    fontFamily: "NotoSansTC_400Regular",
    zIndex: 0,
  },
});
