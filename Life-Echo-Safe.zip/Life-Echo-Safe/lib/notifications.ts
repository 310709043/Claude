import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export async function requestNotificationPermission(): Promise<boolean> {
  if (Platform.OS === "web") return false;
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;
  if (existingStatus !== "granted") {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }
  return finalStatus === "granted";
}

export async function scheduleHourlyReminders() {
  await Notifications.cancelAllScheduledNotificationsAsync();

  const now = new Date();
  const endOfDay = new Date(now);
  endOfDay.setHours(22, 0, 0, 0);

  const startHour = Math.max(now.getHours() + 1, 9);
  const endHour = 22;

  for (let hour = startHour; hour <= endHour; hour++) {
    const triggerDate = new Date(now);
    triggerDate.setHours(hour, 0, 0, 0);

    if (triggerDate.getTime() <= now.getTime()) continue;

    await Notifications.scheduleNotificationAsync({
      content: {
        title: "餘生記",
        body: "你還活著嗎？",
        sound: true,
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: triggerDate,
      },
    });
  }
}

export async function cancelAllReminders() {
  await Notifications.cancelAllScheduledNotificationsAsync();
}

export async function setupNotifications(hasCheckedIn: boolean) {
  const granted = await requestNotificationPermission();
  if (!granted) return;

  if (hasCheckedIn) {
    await cancelAllReminders();
  } else {
    await scheduleHourlyReminders();
  }
}
