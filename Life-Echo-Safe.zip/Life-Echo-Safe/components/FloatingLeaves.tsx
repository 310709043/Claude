import React, { useEffect, useMemo } from "react";
import { StyleSheet, Dimensions, View } from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
  withDelay,
  Easing,
} from "react-native-reanimated";
import { Ionicons } from "@expo/vector-icons";
import { useThemeColors } from "@/lib/ThemeContext";

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get("window");

interface LeafConfig {
  startX: number;
  startY: number;
  driftX: number;
  driftY: number;
  rotation: number;
  duration: number;
  delay: number;
  size: number;
  color: string;
}

function FloatingLeaf({ config }: { config: LeafConfig }) {
  const opacity = useSharedValue(0);
  const translateX = useSharedValue(config.startX);
  const translateY = useSharedValue(config.startY);
  const rotate = useSharedValue(0);

  useEffect(() => {
    opacity.value = withDelay(
      config.delay,
      withRepeat(
        withSequence(
          withTiming(0.75, { duration: 2000, easing: Easing.out(Easing.ease) }),
          withTiming(0.35, { duration: 3000, easing: Easing.inOut(Easing.ease) }),
          withTiming(0.7, { duration: 2500, easing: Easing.out(Easing.ease) }),
          withTiming(0, { duration: 2500, easing: Easing.in(Easing.ease) }),
          withTiming(0, { duration: 2500 })
        ),
        -1,
        false
      )
    );

    translateX.value = withDelay(
      config.delay,
      withRepeat(
        withSequence(
          withTiming(config.startX + config.driftX, {
            duration: config.duration,
            easing: Easing.inOut(Easing.ease),
          }),
          withTiming(config.startX - config.driftX * 0.5, {
            duration: config.duration * 0.8,
            easing: Easing.inOut(Easing.ease),
          }),
          withTiming(config.startX, {
            duration: config.duration * 0.6,
            easing: Easing.inOut(Easing.ease),
          })
        ),
        -1,
        true
      )
    );

    translateY.value = withDelay(
      config.delay,
      withRepeat(
        withSequence(
          withTiming(config.startY + config.driftY, {
            duration: config.duration * 1.3,
            easing: Easing.inOut(Easing.ease),
          }),
          withTiming(config.startY, {
            duration: config.duration * 1.3,
            easing: Easing.inOut(Easing.ease),
          })
        ),
        -1,
        true
      )
    );

    rotate.value = withDelay(
      config.delay,
      withRepeat(
        withSequence(
          withTiming(config.rotation, {
            duration: config.duration * 1.5,
            easing: Easing.inOut(Easing.ease),
          }),
          withTiming(-config.rotation * 0.6, {
            duration: config.duration * 1.2,
            easing: Easing.inOut(Easing.ease),
          }),
          withTiming(0, {
            duration: config.duration,
            easing: Easing.inOut(Easing.ease),
          })
        ),
        -1,
        true
      )
    );
  }, []);

  const animStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { rotate: `${rotate.value}deg` },
    ],
  }));

  return (
    <Animated.View style={[styles.leaf, animStyle]} pointerEvents="none">
      <Ionicons name="leaf" size={config.size} color={config.color} />
    </Animated.View>
  );
}

interface FlickerTextConfig {
  text: string;
  startX: number;
  startY: number;
  driftX: number;
  duration: number;
  delay: number;
  fontSize: number;
}

function FlickerText({ config }: { config: FlickerTextConfig }) {
  const colors = useThemeColors();
  const opacity = useSharedValue(0);
  const translateX = useSharedValue(config.startX);

  useEffect(() => {
    opacity.value = withDelay(
      config.delay,
      withRepeat(
        withSequence(
          withTiming(0.35, { duration: 800, easing: Easing.out(Easing.ease) }),
          withTiming(0.08, { duration: 600, easing: Easing.inOut(Easing.ease) }),
          withTiming(0.3, { duration: 700, easing: Easing.out(Easing.ease) }),
          withTiming(0.05, { duration: 500, easing: Easing.in(Easing.ease) }),
          withTiming(0.25, { duration: 900, easing: Easing.out(Easing.ease) }),
          withTiming(0, { duration: 1200, easing: Easing.in(Easing.ease) }),
          withTiming(0, { duration: 4000 })
        ),
        -1,
        false
      )
    );

    translateX.value = withDelay(
      config.delay,
      withRepeat(
        withSequence(
          withTiming(config.startX + config.driftX, {
            duration: config.duration,
            easing: Easing.inOut(Easing.ease),
          }),
          withTiming(config.startX, {
            duration: config.duration,
            easing: Easing.inOut(Easing.ease),
          })
        ),
        -1,
        true
      )
    );
  }, []);

  const animStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateX: translateX.value }],
  }));

  return (
    <Animated.Text
      style={[
        styles.flickerText,
        {
          top: config.startY,
          fontSize: config.fontSize,
          color: colors.coral,
        },
        animStyle,
      ]}
      pointerEvents="none"
    >
      {config.text}
    </Animated.Text>
  );
}

export default function FloatingLeaves() {
  const colors = useThemeColors();

  const leafConfigs: LeafConfig[] = useMemo(() => [
    { startX: 10, startY: 40, driftX: 50, driftY: 60, rotation: 35, duration: 6000, delay: 0, size: 42, color: "rgba(168, 197, 160, 0.55)" },
    { startX: SCREEN_WIDTH - 70, startY: 100, driftX: -40, driftY: 50, rotation: -30, duration: 7000, delay: 800, size: 36, color: "rgba(168, 197, 160, 0.5)" },
    { startX: 40, startY: 220, driftX: 35, driftY: -40, rotation: 25, duration: 5500, delay: 2000, size: 30, color: "rgba(212, 165, 116, 0.45)" },
    { startX: SCREEN_WIDTH - 90, startY: 320, driftX: -30, driftY: 55, rotation: -40, duration: 8000, delay: 500, size: 38, color: "rgba(168, 197, 160, 0.5)" },
    { startX: 5, startY: 440, driftX: 55, driftY: -30, rotation: 20, duration: 6500, delay: 3000, size: 34, color: "rgba(232, 145, 110, 0.4)" },
    { startX: SCREEN_WIDTH - 55, startY: 530, driftX: -35, driftY: 35, rotation: -25, duration: 7500, delay: 1500, size: 28, color: "rgba(168, 197, 160, 0.45)" },
    { startX: SCREEN_WIDTH / 2 - 30, startY: 160, driftX: 25, driftY: 70, rotation: 30, duration: 9000, delay: 4000, size: 32, color: "rgba(212, 165, 116, 0.4)" },
    { startX: SCREEN_WIDTH / 2 + 40, startY: 400, driftX: -20, driftY: -50, rotation: -35, duration: 7000, delay: 5000, size: 36, color: "rgba(168, 197, 160, 0.5)" },
    { startX: 70, startY: 600, driftX: 30, driftY: -45, rotation: 15, duration: 6800, delay: 2500, size: 40, color: "rgba(168, 197, 160, 0.45)" },
    { startX: SCREEN_WIDTH - 40, startY: 50, driftX: -45, driftY: 65, rotation: -20, duration: 8500, delay: 3500, size: 26, color: "rgba(212, 165, 116, 0.4)" },
    { startX: SCREEN_WIDTH / 2, startY: 550, driftX: 15, driftY: -35, rotation: 28, duration: 7200, delay: 6500, size: 30, color: "rgba(232, 145, 110, 0.35)" },
    { startX: 20, startY: 350, driftX: 40, driftY: 40, rotation: -15, duration: 6200, delay: 7000, size: 24, color: "rgba(168, 197, 160, 0.4)" },
  ], []);

  const flickerConfigs: FlickerTextConfig[] = useMemo(() => [
    { text: "✧", startX: 40, startY: 100, driftX: 15, duration: 5000, delay: 1000, fontSize: 14 },
    { text: "~", startX: SCREEN_WIDTH - 70, startY: 250, driftX: -10, duration: 6000, delay: 3500, fontSize: 16 },
    { text: ".", startX: 25, startY: 420, driftX: 20, duration: 4500, delay: 5500, fontSize: 20 },
    { text: "✧", startX: SCREEN_WIDTH - 50, startY: 500, driftX: -12, duration: 5500, delay: 2000, fontSize: 12 },
  ], []);

  return (
    <View style={styles.container} pointerEvents="none">
      {leafConfigs.map((config, i) => (
        <FloatingLeaf key={`leaf-${i}`} config={config} />
      ))}
      {flickerConfigs.map((config, i) => (
        <FlickerText key={`flicker-${i}`} config={config} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 0,
    overflow: "hidden",
  },
  leaf: {
    position: "absolute",
  },
  flickerText: {
    position: "absolute",
    fontFamily: "NotoSansTC_300Light",
  },
});
