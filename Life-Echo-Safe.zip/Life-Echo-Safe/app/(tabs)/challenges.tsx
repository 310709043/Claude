import React, { useEffect, useMemo, useState, useCallback } from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  Platform,
  ScrollView,
  TextInput,
  Alert,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSpring,
  withDelay,
} from "react-native-reanimated";
import { LinearGradient } from "expo-linear-gradient";
import { useThemeColors } from "@/lib/ThemeContext";
import { useApp } from "@/lib/AppContext";
import { useI18n } from "@/lib/i18n";
import { calculateLifeStats } from "@/lib/life-calculator";
import {
  getCompletedChallenges,
  toggleChallengeComplete,
  getPersonalTasks,
  addPersonalTask,
  togglePersonalTask,
  deletePersonalTask,
  type CompletedChallenge,
  type PersonalTask,
} from "@/lib/storage";
import MarqueeBanner from "@/components/MarqueeBanner";
import FloatingTexts from "@/components/FloatingTexts";

type TaskType = "daily" | "weekly" | "monthly" | "personal";

interface Challenge {
  id: string;
  zh: string;
  en: string;
  icon: keyof typeof Ionicons.glyphMap;
  category: "self" | "explore" | "create" | "connect" | "mindful";
  taskType: "daily" | "weekly" | "monthly";
}

const ALL_CHALLENGES: Challenge[] = [
  { id: "c1", zh: "一個人去咖啡廳坐一個下午", en: "Spend an afternoon alone at a cafe", icon: "cafe-outline", category: "self", taskType: "weekly" },
  { id: "c2", zh: "嘗試一道從未做過的料理", en: "Cook a dish you've never tried", icon: "restaurant-outline", category: "create", taskType: "weekly" },
  { id: "c3", zh: "去一個從未去過的公園散步", en: "Walk in a park you've never visited", icon: "leaf-outline", category: "explore", taskType: "weekly" },
  { id: "c4", zh: "寫一封給未來自己的信", en: "Write a letter to your future self", icon: "mail-outline", category: "self", taskType: "monthly" },
  { id: "c5", zh: "看一場電影，不看手機", en: "Watch a movie without checking your phone", icon: "film-outline", category: "mindful", taskType: "weekly" },
  { id: "c6", zh: "整理房間的一個角落", en: "Declutter one corner of your room", icon: "home-outline", category: "self", taskType: "weekly" },
  { id: "c7", zh: "去書店逛逛，買一本書", en: "Browse a bookstore and buy a book", icon: "book-outline", category: "explore", taskType: "monthly" },
  { id: "c8", zh: "早起看一次日出", en: "Wake up early to watch the sunrise", icon: "sunny-outline", category: "mindful", taskType: "monthly" },
  { id: "c9", zh: "學一首新歌", en: "Learn a new song", icon: "musical-notes-outline", category: "create", taskType: "monthly" },
  { id: "c10", zh: "嘗試 10 分鐘冥想", en: "Try 10 minutes of meditation", icon: "flower-outline", category: "mindful", taskType: "daily" },
  { id: "c11", zh: "拍一張讓自己開心的照片", en: "Take a photo that makes you happy", icon: "camera-outline", category: "create", taskType: "daily" },
  { id: "c12", zh: "去夜市獨自享受美食", en: "Enjoy street food alone at a night market", icon: "fast-food-outline", category: "explore", taskType: "weekly" },
  { id: "c13", zh: "種一棵小植物", en: "Plant a small plant", icon: "leaf-outline", category: "create", taskType: "monthly" },
  { id: "c14", zh: "在家裡點蠟燭放鬆一晚", en: "Light candles and relax for an evening", icon: "flame-outline", category: "mindful", taskType: "weekly" },
  { id: "c15", zh: "去附近的山步道走走", en: "Hike a nearby trail", icon: "walk-outline", category: "explore", taskType: "weekly" },
  { id: "c16", zh: "寫下三件感恩的事", en: "Write down three things you're grateful for", icon: "heart-outline", category: "self", taskType: "daily" },
  { id: "c17", zh: "嘗試一杯新飲料", en: "Try a new drink", icon: "wine-outline", category: "explore", taskType: "daily" },
  { id: "c18", zh: "關掉手機一小時", en: "Turn off your phone for one hour", icon: "phone-portrait-outline", category: "mindful", taskType: "daily" },
  { id: "c19", zh: "給自己做一個手工小禮物", en: "Make a handmade gift for yourself", icon: "gift-outline", category: "create", taskType: "monthly" },
  { id: "c20", zh: "去一個從未去過的餐廳吃飯", en: "Eat at a restaurant you've never been to", icon: "restaurant-outline", category: "explore", taskType: "monthly" },
  { id: "c21", zh: "畫一幅簡單的畫", en: "Draw a simple picture", icon: "brush-outline", category: "create", taskType: "weekly" },
  { id: "c22", zh: "泡一個舒服的澡", en: "Take a long relaxing bath", icon: "water-outline", category: "mindful", taskType: "daily" },
  { id: "c23", zh: "去圖書館待一個下午", en: "Spend an afternoon at the library", icon: "library-outline", category: "self", taskType: "monthly" },
  { id: "c24", zh: "寫日記記錄今天的小確幸", en: "Journal about today's small joys", icon: "create-outline", category: "self", taskType: "daily" },
  { id: "c25", zh: "學一個新的伸展動作", en: "Learn a new stretching exercise", icon: "body-outline", category: "mindful", taskType: "daily" },
  { id: "c26", zh: "聽一張從未聽過的專輯", en: "Listen to an album you've never heard", icon: "headset-outline", category: "explore", taskType: "daily" },
  { id: "c27", zh: "給陌生人一個微笑", en: "Smile at a stranger", icon: "happy-outline", category: "connect", taskType: "daily" },
  { id: "c28", zh: "坐公車到終點站看看", en: "Ride the bus to the last stop and explore", icon: "bus-outline", category: "explore", taskType: "monthly" },
  { id: "c29", zh: "買一束花給自己", en: "Buy yourself a bouquet of flowers", icon: "rose-outline", category: "self", taskType: "weekly" },
  { id: "c30", zh: "寫下一個年度願望", en: "Write down a wish for the year", icon: "star-outline", category: "self", taskType: "monthly" },
];

const CATEGORY_COLORS: Record<string, string> = {
  self: "#E8916E",
  explore: "#8DBAD4",
  create: "#A094C7",
  connect: "#F2A04A",
  mindful: "#A8C5A0",
};

const CATEGORY_LABELS: Record<string, { zh: string; en: string }> = {
  self: { zh: "自我成長", en: "Self Growth" },
  explore: { zh: "探索世界", en: "Explore" },
  create: { zh: "創造力", en: "Create" },
  connect: { zh: "人際連結", en: "Connect" },
  mindful: { zh: "正念放鬆", en: "Mindful" },
};

const TASK_TYPE_LABELS: Record<TaskType, { zh: string; en: string }> = {
  daily: { zh: "日任務", en: "Daily" },
  weekly: { zh: "週任務", en: "Weekly" },
  monthly: { zh: "月任務", en: "Monthly" },
  personal: { zh: "個人任務", en: "Personal" },
};

function ChallengeItem({ challenge, index, isCompleted, onToggle, lang, colors }: {
  challenge: Challenge;
  index: number;
  isCompleted: boolean;
  onToggle: () => void;
  lang: string;
  colors: any;
}) {
  const scale = useSharedValue(0);
  const catColor = CATEGORY_COLORS[challenge.category];

  useEffect(() => {
    scale.value = withDelay(index * 60, withSpring(1, { damping: 15, stiffness: 120 }));
  }, []);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: scale.value,
  }));

  return (
    <Animated.View style={animStyle}>
      <Pressable
        onPress={onToggle}
        style={({ pressed }) => [
          styles.challengeItem,
          { backgroundColor: colors.cardBg, borderLeftColor: catColor, borderLeftWidth: 3 },
          isCompleted && { opacity: 0.6 },
          pressed && { transform: [{ scale: 0.97 }] },
        ]}
      >
        <View style={[styles.challengeIcon, { backgroundColor: catColor + "18" }]}>
          <Ionicons name={challenge.icon} size={20} color={catColor} />
        </View>
        <View style={styles.challengeContent}>
          <Text
            style={[
              styles.challengeText,
              { color: colors.textPrimary },
              isCompleted && { textDecorationLine: "line-through" as const, color: colors.textMuted },
            ]}
          >
            {lang === "zh" ? challenge.zh : challenge.en}
          </Text>
          <Text style={[styles.categoryTag, { color: catColor }]}>
            {lang === "zh" ? CATEGORY_LABELS[challenge.category].zh : CATEGORY_LABELS[challenge.category].en}
          </Text>
        </View>
        <View style={[styles.checkCircle, { borderColor: catColor }, isCompleted && { backgroundColor: catColor }]}>
          {isCompleted && <Ionicons name="checkmark" size={14} color="#FFF" />}
        </View>
      </Pressable>
    </Animated.View>
  );
}

function PersonalTaskItem({ task, index, onToggle, onDelete, colors }: {
  task: PersonalTask;
  index: number;
  onToggle: () => void;
  onDelete: () => void;
  colors: any;
}) {
  const scale = useSharedValue(0);
  const catColor = "#F2A04A";

  useEffect(() => {
    scale.value = withDelay(index * 60, withSpring(1, { damping: 15, stiffness: 120 }));
  }, []);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: scale.value,
  }));

  return (
    <Animated.View style={animStyle}>
      <Pressable
        onPress={onToggle}
        style={({ pressed }) => [
          styles.challengeItem,
          { backgroundColor: colors.cardBg, borderLeftColor: catColor, borderLeftWidth: 3 },
          task.completed && { opacity: 0.6 },
          pressed && { transform: [{ scale: 0.97 }] },
        ]}
      >
        <View style={[styles.challengeIcon, { backgroundColor: catColor + "18" }]}>
          <Ionicons name="person-outline" size={20} color={catColor} />
        </View>
        <View style={styles.challengeContent}>
          <Text
            style={[
              styles.challengeText,
              { color: colors.textPrimary },
              task.completed && { textDecorationLine: "line-through" as const, color: colors.textMuted },
            ]}
          >
            {task.text}
          </Text>
        </View>
        <Pressable onPress={onDelete} hitSlop={8} style={{ marginRight: 8 }}>
          <Ionicons name="trash-outline" size={18} color={colors.textMuted} />
        </Pressable>
        <View style={[styles.checkCircle, { borderColor: catColor }, task.completed && { backgroundColor: catColor }]}>
          {task.completed && <Ionicons name="checkmark" size={14} color="#FFF" />}
        </View>
      </Pressable>
    </Animated.View>
  );
}

export default function ChallengesScreen() {
  const insets = useSafeAreaInsets();
  const colors = useThemeColors();
  const { user, birthday } = useApp();
  const { t, lang } = useI18n();
  const webTopInset = Platform.OS === "web" ? 67 : 0;
  const [completedChallenges, setCompletedChallenges] = useState<CompletedChallenge[]>([]);
  const [personalTasks, setPersonalTasks] = useState<PersonalTask[]>([]);
  const [activeTab, setActiveTab] = useState<TaskType>("daily");
  const [newTaskText, setNewTaskText] = useState("");

  const fadeIn = useSharedValue(0);
  useEffect(() => {
    if (!user) {
      router.replace("/login");
      return;
    }
    fadeIn.value = withTiming(1, { duration: 600 });
    loadData();
  }, [user]);

  const loadData = useCallback(async () => {
    const [completed, tasks] = await Promise.all([
      getCompletedChallenges(),
      getPersonalTasks(),
    ]);
    setCompletedChallenges(completed);
    setPersonalTasks(tasks);
  }, []);

  const containerAnim = useAnimatedStyle(() => ({ opacity: fadeIn.value }));

  const stats = birthday ? calculateLifeStats(birthday) : null;
  const remainingWeekends = stats?.remainingWeekends || 0;

  const completedIds = useMemo(() => {
    return new Set(completedChallenges.map((c) => c.id));
  }, [completedChallenges]);

  const filteredChallenges = useMemo(() => {
    if (activeTab === "personal") return [];
    return ALL_CHALLENGES.filter((c) => c.taskType === activeTab);
  }, [activeTab]);

  const totalCount = activeTab === "personal"
    ? personalTasks.length
    : filteredChallenges.length;
  const completedCount = activeTab === "personal"
    ? personalTasks.filter((t) => t.completed).length
    : filteredChallenges.filter((c) => completedIds.has(c.id)).length;
  const progress = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

  const handleToggle = useCallback(async (id: string) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const updated = await toggleChallengeComplete(id);
    setCompletedChallenges(updated);
  }, []);

  const handleTogglePersonal = useCallback(async (id: string) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const updated = await togglePersonalTask(id);
    setPersonalTasks(updated);
  }, []);

  const handleDeletePersonal = useCallback(async (id: string) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const updated = await deletePersonalTask(id);
    setPersonalTasks(updated);
  }, []);

  const handleAddPersonal = useCallback(async () => {
    if (!newTaskText.trim()) return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const updated = await addPersonalTask(newTaskText.trim());
    setPersonalTasks(updated);
    setNewTaskText("");
  }, [newTaskText]);

  if (!user) return null;

  const marqueeContent = `${user.username} ${t("marqueeText")}`;

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientMid, colors.gradientEnd]}
      style={styles.screen}
      start={{ x: 0, y: 0 }}
      end={{ x: 0.5, y: 1 }}
    >
      <FloatingTexts />
      <ScrollView
        style={styles.screen}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: insets.top + webTopInset + 8,
            paddingBottom: insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <MarqueeBanner text={marqueeContent} />

        <Animated.View style={[styles.container, containerAnim]}>
          <Text style={[styles.pageTitle, { color: colors.textPrimary }]}>
            {lang === "zh" ? "獨處挑戰清單" : "Solo Challenges"}
          </Text>
          <Text style={[styles.pageSubtitle, { color: colors.textSecondary }]}>
            {lang === "zh"
              ? `你還有 ${remainingWeekends.toLocaleString()} 個週末，好好利用吧`
              : `You have ${remainingWeekends.toLocaleString()} weekends left, make them count`}
          </Text>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filterRow}
          >
            {(["daily", "weekly", "monthly", "personal"] as TaskType[]).map((tab) => {
              const isActive = activeTab === tab;
              return (
                <Pressable
                  key={tab}
                  onPress={() => setActiveTab(tab)}
                  style={[
                    styles.filterPill,
                    { backgroundColor: isActive ? colors.coral : colors.cardBg },
                  ]}
                >
                  <Text style={[
                    styles.filterPillText,
                    { color: isActive ? "#FFF" : colors.textSecondary },
                  ]}>
                    {lang === "zh" ? TASK_TYPE_LABELS[tab].zh : TASK_TYPE_LABELS[tab].en}
                  </Text>
                </Pressable>
              );
            })}
          </ScrollView>

          <View style={[styles.progressCard, { backgroundColor: colors.cardBg }]}>
            <View style={styles.progressHeader}>
              <Text style={[styles.progressTitle, { color: colors.textPrimary }]}>
                {lang === "zh"
                  ? `${TASK_TYPE_LABELS[activeTab].zh}進度`
                  : `${TASK_TYPE_LABELS[activeTab].en} Progress`}
              </Text>
              <Text style={[styles.progressCount, { color: colors.coral }]}>
                {completedCount}/{totalCount}
              </Text>
            </View>
            <View style={[styles.progressBarBg, { backgroundColor: colors.border }]}>
              <View
                style={[
                  styles.progressBarFill,
                  { width: `${Math.min(100, progress)}%`, backgroundColor: colors.coral },
                ]}
              />
            </View>
            {!birthday && (
              <Pressable
                onPress={() => router.push("/birthday")}
                style={styles.setupHint}
              >
                <Ionicons name="information-circle-outline" size={14} color={colors.gold} />
                <Text style={[styles.setupHintText, { color: colors.gold }]}>
                  {lang === "zh" ? "設定生日以獲取個人化挑戰" : "Set birthday for personalized challenges"}
                </Text>
              </Pressable>
            )}
          </View>

          {activeTab !== "personal" && (
            <View style={styles.categoryRow}>
              {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
                <View key={key} style={styles.categoryChip}>
                  <View style={[styles.categoryDot, { backgroundColor: CATEGORY_COLORS[key] }]} />
                  <Text style={[styles.categoryChipText, { color: colors.textSecondary }]}>
                    {lang === "zh" ? label.zh : label.en}
                  </Text>
                </View>
              ))}
            </View>
          )}

          {activeTab === "personal" && (
            <View style={[styles.addTaskRow, { backgroundColor: colors.cardBg }]}>
              <TextInput
                style={[styles.addTaskInput, {
                  backgroundColor: colors.background + "80",
                  borderColor: colors.border,
                  color: colors.textPrimary,
                }]}
                placeholder={lang === "zh" ? "新增個人任務..." : "Add personal task..."}
                placeholderTextColor={colors.textMuted}
                value={newTaskText}
                onChangeText={setNewTaskText}
                maxLength={100}
              />
              <Pressable
                onPress={handleAddPersonal}
                disabled={!newTaskText.trim()}
                style={({ pressed }) => [
                  styles.addTaskBtn,
                  { backgroundColor: newTaskText.trim() ? colors.coral : colors.border },
                  pressed && newTaskText.trim() && { opacity: 0.85 },
                ]}
              >
                <Ionicons name="add" size={22} color={newTaskText.trim() ? "#FFF" : colors.textMuted} />
              </Pressable>
            </View>
          )}

          <View style={styles.challengeList}>
            {activeTab === "personal" ? (
              personalTasks.length === 0 ? (
                <View style={styles.emptyState}>
                  <Ionicons name="add-circle-outline" size={36} color={colors.textMuted} />
                  <Text style={[styles.emptyStateText, { color: colors.textMuted }]}>
                    {lang === "zh" ? "還沒有個人任務，新增一個吧" : "No personal tasks yet, add one above"}
                  </Text>
                </View>
              ) : (
                personalTasks.map((task, index) => (
                  <PersonalTaskItem
                    key={task.id}
                    task={task}
                    index={index}
                    onToggle={() => handleTogglePersonal(task.id)}
                    onDelete={() => handleDeletePersonal(task.id)}
                    colors={colors}
                  />
                ))
              )
            ) : (
              filteredChallenges.map((challenge, index) => (
                <ChallengeItem
                  key={challenge.id}
                  challenge={challenge}
                  index={index}
                  isCompleted={completedIds.has(challenge.id)}
                  onToggle={() => handleToggle(challenge.id)}
                  lang={lang}
                  colors={colors}
                />
              ))
            )}
          </View>
        </Animated.View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  scrollContent: { flexGrow: 1 },
  container: {
    paddingHorizontal: 20,
    gap: 16,
    paddingTop: 12,
  },
  pageTitle: {
    fontSize: 26,
    fontFamily: "NotoSansTC_700Bold",
  },
  pageSubtitle: {
    fontSize: 14,
    fontFamily: "NotoSansTC_400Regular",
    marginTop: -8,
  },
  filterRow: {
    flexDirection: "row",
    gap: 10,
    paddingVertical: 2,
  },
  filterPill: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  filterPillText: {
    fontSize: 13,
    fontFamily: "NotoSansTC_700Bold",
  },
  progressCard: {
    borderRadius: 20,
    padding: 20,
    gap: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 16,
    elevation: 3,
  },
  progressHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  progressTitle: {
    fontSize: 16,
    fontFamily: "NotoSansTC_700Bold",
  },
  progressCount: {
    fontSize: 16,
    fontFamily: "NotoSansTC_700Bold",
  },
  progressBarBg: {
    height: 8,
    borderRadius: 4,
    overflow: "hidden",
  },
  progressBarFill: {
    height: "100%",
    borderRadius: 4,
  },
  setupHint: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  setupHintText: {
    fontSize: 12,
    fontFamily: "NotoSansTC_400Regular",
  },
  categoryRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  categoryChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  categoryDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  categoryChipText: {
    fontSize: 11,
    fontFamily: "NotoSansTC_400Regular",
  },
  addTaskRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderRadius: 16,
    padding: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  addTaskInput: {
    flex: 1,
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 14,
    fontFamily: "NotoSansTC_400Regular",
  },
  addTaskBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  challengeList: {
    gap: 10,
  },
  challengeItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderRadius: 16,
    gap: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  challengeIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  challengeContent: {
    flex: 1,
    gap: 4,
  },
  challengeText: {
    fontSize: 14,
    fontFamily: "NotoSansTC_500Medium",
    lineHeight: 20,
  },
  categoryTag: {
    fontSize: 11,
    fontFamily: "NotoSansTC_400Regular",
  },
  checkCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyState: {
    alignItems: "center",
    gap: 10,
    paddingVertical: 32,
  },
  emptyStateText: {
    fontSize: 14,
    fontFamily: "NotoSansTC_400Regular",
    textAlign: "center",
  },
});
