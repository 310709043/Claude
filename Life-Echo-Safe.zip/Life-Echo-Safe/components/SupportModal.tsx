import React from "react";
import { View, Text, StyleSheet, Modal, Pressable, Platform, Linking, Alert } from "react-native";
import { BlurView } from "expo-blur";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { useTheme } from "@/lib/ThemeContext";
import { useI18n } from "@/lib/i18n";

interface SupportModalProps {
  visible: boolean;
  onClose: () => void;
}

export default function SupportModal({ visible, onClose }: SupportModalProps) {
  const { mode, colors } = useTheme();
  const { t, lang } = useI18n();
  const isWeb = Platform.OS === "web";

  const handleDonate = async () => {
    if (Platform.OS !== "web") {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    const message = lang === "zh"
      ? "不請沒關係，你好好活著就好"
      : "It's okay if you don't, just keep living well";
    Alert.alert("❤️", message, [{ text: "OK" }]);
  };

  const handleFeedback = async () => {
    if (Platform.OS !== "web") {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    Linking.openURL("https://forms.gle/FdmV7Y5NWwyw6rzu7");
  };

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.overlay}>
        {!isWeb ? (
          <BlurView
            intensity={40}
            tint={mode === "dark" ? "dark" : "light"}
            style={StyleSheet.absoluteFill}
          />
        ) : (
          <View style={[StyleSheet.absoluteFill, styles.webBlur]} />
        )}
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View style={[styles.card, { backgroundColor: colors.cardBg }]}>
          <Pressable onPress={onClose} style={styles.closeBtn} hitSlop={12}>
            <Ionicons name="close" size={22} color={colors.textMuted} />
          </Pressable>

          <View style={[styles.iconCircle, { backgroundColor: "rgba(232, 145, 110, 0.1)" }]}>
            <Ionicons name="cafe" size={28} color={colors.coral} />
          </View>

          <Text style={[styles.title, { color: colors.textPrimary }]}>
            {lang === "zh" ? "支持開發者" : "Support Developer"}
          </Text>

          <Text style={[styles.story, { color: colors.textSecondary }]}>
            {lang === "zh"
              ? "這款測試App是由一個人慢慢做出來的，如果你覺得可以支持他在半年內上架，你覺得有用的話，你可以請開發者喝一杯咖啡。"
              : "This app is built by one person, slowly. If you find it useful and want to support its launch within 6 months, you can buy the developer a coffee."}
          </Text>

          <View style={[styles.accountCard, { backgroundColor: colors.background }]}>
            <Text style={[styles.accountLabel, { color: colors.textMuted }]}>
              {lang === "zh" ? "收款帳戶" : "Account"}
            </Text>
            <Text style={[styles.accountName, { color: colors.textPrimary }]}>
              餘生記Life Echo Studio
            </Text>
            <Text style={[styles.accountNumber, { color: colors.coral }]}>
              (013) 079506165593
            </Text>
          </View>

          <Pressable
            onPress={handleDonate}
            style={({ pressed }) => [
              styles.donateBtn,
              pressed && { opacity: 0.85, transform: [{ scale: 0.97 }] },
            ]}
          >
            <LinearGradient
              colors={[colors.coral, colors.coralSoft]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.donateBtnGradient}
            >
              <Ionicons name="cafe-outline" size={18} color="#FFF" />
              <Text style={styles.donateBtnText}>
                {lang === "zh" ? "請喝咖啡" : "Buy a Coffee"}
              </Text>
            </LinearGradient>
          </Pressable>

          <Pressable
            onPress={handleFeedback}
            style={({ pressed }) => [
              styles.feedbackBtn,
              { borderColor: colors.sage },
              pressed && { opacity: 0.85, transform: [{ scale: 0.97 }] },
            ]}
          >
            <Ionicons name="chatbubble-ellipses-outline" size={18} color={colors.sage} />
            <Text style={[styles.feedbackBtnText, { color: colors.sage }]}>
              {lang === "zh" ? "意見回饋" : "Feedback"}
            </Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 24,
  },
  webBlur: {
    backgroundColor: "rgba(0,0,0,0.35)",
  },
  card: {
    borderRadius: 24,
    padding: 28,
    alignItems: "center",
    gap: 14,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 20,
    elevation: 8,
    width: "100%",
    maxWidth: 340,
  },
  closeBtn: {
    position: "absolute",
    top: 16,
    right: 16,
    zIndex: 1,
  },
  iconCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 18,
    fontFamily: "NotoSansTC_700Bold",
  },
  story: {
    fontSize: 14,
    fontFamily: "NotoSansTC_400Regular",
    lineHeight: 22,
    textAlign: "center",
  },
  accountCard: {
    width: "100%",
    borderRadius: 14,
    padding: 16,
    alignItems: "center",
    gap: 4,
  },
  accountLabel: {
    fontSize: 11,
    fontFamily: "NotoSansTC_400Regular",
  },
  accountName: {
    fontSize: 14,
    fontFamily: "NotoSansTC_700Bold",
  },
  accountNumber: {
    fontSize: 16,
    fontFamily: "NotoSansTC_700Bold",
    letterSpacing: 1,
  },
  donateBtn: {
    borderRadius: 20,
    overflow: "hidden",
    marginTop: 4,
  },
  donateBtnGradient: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 28,
    borderRadius: 20,
  },
  donateBtnText: {
    fontSize: 15,
    fontFamily: "NotoSansTC_700Bold",
    color: "#FFF",
  },
  feedbackBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 11,
    paddingHorizontal: 28,
    borderRadius: 20,
    borderWidth: 1.5,
  },
  feedbackBtnText: {
    fontSize: 15,
    fontFamily: "NotoSansTC_700Bold",
  },
});
